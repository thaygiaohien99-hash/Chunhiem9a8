import React from 'react';
import { User, UserRole, UserLevel } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
  user: User;
  onLogout: () => void;
}

const LEVEL_COLORS: Record<UserLevel, string> = {
  [UserLevel.LEVEL_1]: 'bg-gray-500',
  [UserLevel.LEVEL_2]: 'bg-green-500',
  [UserLevel.LEVEL_3]: 'bg-blue-600',
  [UserLevel.LEVEL_4]: 'bg-yellow-500',
};

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange, user, onLogout }) => {
  const isAdmin = user.role === UserRole.ADMIN;
  
  const navItems = [
    { id: 'home', label: 'Trang Chủ', icon: '🏠' },
    { id: 'test', label: isAdmin ? 'Quản lý' : 'Kiểm tra', icon: '📝' },
    { id: 'battle', label: 'Thách Đấu', icon: '⚔️' },
    { id: 'leaderboard', label: 'Xếp Hạng', icon: '🏆' },
    { id: 'profile', label: 'Cá Nhân', icon: '👤' },
  ];

  const currentLevel = (Object.values(UserLevel) as UserLevel[]).find(l => l === calculateLevelBadge(user)) || UserLevel.LEVEL_1;

  function calculateLevelBadge(u: User): UserLevel {
     // Simplified logic for UI badge display, real logic in dataService
     if (u.totalScore > 260) return UserLevel.LEVEL_4;
     if (u.totalScore > 156) return UserLevel.LEVEL_3;
     if (u.totalScore > 65) return UserLevel.LEVEL_2;
     return UserLevel.LEVEL_1;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-bio-700 text-white shadow-lg sticky top-0 z-50 relative">
        <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center relative z-10">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🧬</span>
            <h1 className="text-xl font-bold tracking-tight hidden sm:block">Sinh Học LMS</h1>
            {isAdmin && <span className="bg-red-500 text-xs px-2 py-1 rounded ml-2 font-bold">ADMIN</span>}
          </div>
          
          <div className="flex items-center gap-4">
            {!isAdmin && (
              <div className={`px-3 py-1 rounded-full text-xs font-bold text-white flex items-center gap-1 ${LEVEL_COLORS[currentLevel]}`}>
                <span>🎖️</span> {currentLevel}
              </div>
            )}
            <div className="text-sm text-bio-100 hidden sm:block">
              Xin chào, <b>{user.name}</b>
            </div>
            <button 
              onClick={onLogout}
              className="bg-bio-800 hover:bg-bio-900 text-white text-xs px-3 py-2 rounded transition"
            >
              Đăng xuất
            </button>
          </div>
        </div>

        {/* Center Timer Portal Target - Absolute positioning to stay in center regardless of side content */}
        <div 
            id="header-timer-portal" 
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none"
        >
            {/* Timer will be injected here via React Portal */}
        </div>
      </header>

      {/* Mobile Nav Sticky Bottom */}
      <div className="fixed bottom-0 left-0 right-0 bg-bio-700 border-t border-bio-600 flex justify-around p-2 md:hidden z-40 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`flex flex-col items-center justify-center p-2 rounded-lg w-full transition-all duration-200 ${
                activeTab === item.id 
                ? 'bg-bio-900 text-white shadow-inner transform -translate-y-1' 
                : 'text-bio-100 hover:bg-bio-600 hover:text-white'
            }`}
          >
            <span className="text-xl mb-0.5">{item.icon}</span>
            <span className={`text-[10px] ${activeTab === item.id ? 'font-bold' : 'font-medium'}`}>{item.label}</span>
          </button>
        ))}
      </div>

      {/* Desktop Nav Sidebar & Content */}
      <div className="flex-1 flex max-w-7xl mx-auto w-full">
        {/* Sidebar */}
        <aside className="hidden md:block w-64 bg-white border-r border-gray-200 py-6">
          <nav className="space-y-1 px-2">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors ${
                  activeTab === item.id 
                    ? 'bg-red-50 text-red-700 border-l-4 border-red-600' 
                    : 'text-gray-600 hover:bg-red-50 hover:text-red-600'
                }`}
              >
                <span className="mr-3 text-xl">{item.icon}</span>
                {item.label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 pb-24 md:p-8 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
};