import { User, UserLevel, Exam, Question, ExamResult } from '../types';

// --- CẤU HÌNH API ---
// HÃY THAY THẾ CHUỖI BÊN DƯỚI BẰNG "WEB APP URL" BẠN VỪA COPY Ở BƯỚC 4
export const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwn7SlQ5qNqo5M1QemjapcK80TfPfofIp6UVddPC_JvRL6uAL4afdwghizh6QZLKg3g7A/exec'; 

// --- Local Storage Helpers (Fallback/Offline) ---
export const getStorageData = <T>(key: string, defaultVal: T): T => {
  const stored = localStorage.getItem(key);
  return stored ? JSON.parse(stored) : defaultVal;
};

export const setStorageData = (key: string, value: any) => {
  localStorage.setItem(key, JSON.stringify(value));
};

// --- Level Calculation ---
export const calculateLevel = (totalScore: number, history: { score: number }[]): UserLevel => {
  const last5 = history.slice(-5).map(h => h.score);
  const minLast5 = last5.length > 0 ? Math.min(...last5) : 0;
  
  if (totalScore > 260 && last5.length >= 5 && minLast5 >= 9) return UserLevel.LEVEL_4;
  if (totalScore >= 156 && last5.length >= 5 && minLast5 >= 7) return UserLevel.LEVEL_3;
  if (totalScore >= 65 && last5.length >= 5 && minLast5 >= 6) return UserLevel.LEVEL_2;
  return UserLevel.LEVEL_1;
};

// --- Cloud API Integration ---

// 1. Fetch Exams from Cloud
export const getExams = async (): Promise<Exam[]> => {
  try {
    // Fallback to local if URL not valid
    if (!GOOGLE_SCRIPT_URL.includes('http')) return getStorageData('bio_exams', []);

    // Add timestamp to prevent browser caching of GET requests
    const response = await fetch(`${GOOGLE_SCRIPT_URL}?action=get_exams&_t=${Date.now()}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    if (data.success && data.exams) {
      // Cache locally
      setStorageData('bio_exams', data.exams);
      return data.exams;
    }
    return getStorageData('bio_exams', []);
  } catch (error) {
    console.warn("Offline mode or API Error (getExams): using local data.", error);
    return getStorageData('bio_exams', []);
  }
};

// Helper: Get Exam by ID (used for Battle Room Code)
export const getExamById = async (id: string): Promise<Exam | null> => {
    const allExams = await getExams();
    return allExams.find(e => e.id === id) || null;
};

// 2. Publish New Exam to Cloud
export const publishExamToCloud = async (exam: Exam): Promise<boolean> => {
  try {
    // FIX: Use text/plain to avoid CORS Preflight (OPTIONS) failure with Google Apps Script
    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8',
      },
      body: JSON.stringify({
        action: 'create_exam',
        exam: exam
      })
    });

    if (!response.ok) return false;

    const result = await response.json();
    
    // Update Local Cache immediately
    if (result.success) {
      const currentExams = getStorageData<Exam[]>('bio_exams', []);
      // Check if update or new
      const exists = currentExams.find(e => e.id === exam.id);
      let updatedList;
      if (exists) {
        updatedList = currentExams.map(e => e.id === exam.id ? exam : e);
      } else {
        updatedList = [exam, ...currentExams];
      }
      setStorageData('bio_exams', updatedList);
    }
    
    return result.success;
  } catch (error) {
    console.error("Failed to publish exam", error);
    return false;
  }
};

// Delete Exam (Admin) - Fixed with Optimistic Update
export const deleteExamFromCloud = async (examId: string): Promise<boolean> => {
  // 1. Always delete locally first (Optimistic update)
  const currentExams = getStorageData<Exam[]>('bio_exams', []);
  const updatedList = currentExams.filter(e => e.id !== examId);
  setStorageData('bio_exams', updatedList);

  try {
    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'delete_exam', examId: examId })
    });

    // Even if server returns false (e.g. not found or script error), 
    // we consider it "deleted" from the user's perspective.
    return true; 
  } catch (error) {
    console.error("Failed to delete exam from cloud, keeping local delete", error);
    return true; 
  }
};

// 3. Submit Exam Result & Update User Stats
export const submitExamResultToCloud = async (
  userPhone: string, 
  examResult: ExamResult
): Promise<{ success: boolean; updatedUser?: User }> => {
  try {
    // FIX: Use text/plain for POST requests
    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8',
      },
      body: JSON.stringify({
        action: 'submit_result',
        phone: userPhone,
        result: examResult
      })
    });
    
    if (!response.ok) return { success: false };

    const data = await response.json();

    if (data.success && data.user) {
      // Update local storage for the user
      localStorage.setItem(`user_${userPhone}`, JSON.stringify(data.user));
      return { success: true, updatedUser: data.user };
    }
    return { success: false };
  } catch (error) {
    console.error("Failed to submit result", error);
    // Fallback logic could go here
    return { success: false };
  }
};

// 4. Fetch Leaderboard
export const fetchCloudLeaderboard = async (filter: string): Promise<any[]> => {
  try {
    // Add timestamp to prevent caching
    const response = await fetch(`${GOOGLE_SCRIPT_URL}?action=get_leaderboard&filter=${filter}&_t=${Date.now()}`);
    if (!response.ok) return [];
    
    const data = await response.json();
    if (data.success) {
      return data.leaderboard;
    }
    return [];
  } catch (error) {
    console.error("Failed to fetch leaderboard", error);
    return [];
  }
};

// New Helper: Get participants for a specific exam
export const getExamParticipants = async (examId: string): Promise<any[]> => {
  try {
    // Reuse leaderboard fetch to get all users, filtering 'MONTH' is usually enough for recent data, 
    // or assume 'ALL' if supported. Using 'MONTH' as a safe default for now.
    const users = await fetchCloudLeaderboard('MONTH'); 
    
    const participants: any[] = [];
    
    users.forEach((u: any) => {
      // Find all attempts for this exam
      const attempts = u.examHistory?.filter((h: any) => h.examId === examId);
      if (attempts && attempts.length > 0) {
        // Add each attempt or just the latest? Let's add the latest or best.
        // For Admin view, seeing the BEST score is usually preferred, or the LATEST.
        // Let's iterate and add a record for this user.
        
        // Find best score
        const bestAttempt = attempts.reduce((prev: any, current: any) => (prev.score > current.score) ? prev : current);
        
        participants.push({
          name: u.name,
          className: u.className,
          score: bestAttempt.score,
          date: bestAttempt.date,
          startTime: bestAttempt.startTime, 
          endTime: bestAttempt.endTime,
          detailedAnswers: bestAttempt.detailedAnswers || [] // Include Detailed Answers
        });
      }
    });

    // Sort by Score DESC
    return participants.sort((a, b) => b.score - a.score);

  } catch (error) {
    console.error("Failed to fetch exam participants", error);
    return [];
  }
};

// Legacy stubs for compatibility if needed, redirected to local helpers
export const saveExam = (exam: Exam) => {
   const list = getStorageData<Exam[]>('bio_exams', []);
   setStorageData('bio_exams', [exam, ...list]);
}

export const saveExamsList = (exams: Exam[]) => {
   setStorageData('bio_exams', exams);
}