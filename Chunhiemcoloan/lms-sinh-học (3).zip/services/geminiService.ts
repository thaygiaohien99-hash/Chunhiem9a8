
import { GoogleGenAI } from "@google/genai";
import { Question } from "../types";

// Helper to generate questions from topic
export const generateBiologyQuestions = async (topic: string, count: number = 5): Promise<Question[]> => {
  // Fix: Obtained API key directly from process.env.API_KEY as per instructions.
  // Always use {apiKey: process.env.API_KEY} as named parameter.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `
    Bạn là một giáo viên sinh học. Hãy tạo ra ${count} câu hỏi trắc nghiệm (MCQ) về chủ đề "${topic}".
    Định dạng JSON output như sau (không kèm markdown):
    [
      {
        "text": "Nội dung câu hỏi",
        "options": ["Đáp án A", "Đáp án B", "Đáp án C", "Đáp án D"],
        "correctAnswer": "A" hoặc "B" hoặc "C" hoặc "D"
      }
    ]
    Đảm bảo đáp án đúng là một trong các chữ cái A, B, C, D in hoa.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview', 
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    // Clean JSON string before parsing
    let text = response.text || '';
    text = text.replace(/^```json/, '').replace(/^```/, '').replace(/```$/, '').trim();

    if (!text) return [];

    const rawQuestions = JSON.parse(text);
    
    return rawQuestions.map((q: any, index: number) => ({
      id: `gen-${Date.now()}-${index}`,
      type: 'MCQ',
      text: q.text,
      options: q.options,
      correctAnswer: q.correctAnswer
    }));

  } catch (error) {
    console.error("Gemini Generation Error:", error);
    return [];
  }
};

// Helper to convert File to Base64
export const fileToGenerativePart = async (file: File): Promise<{ inlineData: { data: string; mimeType: string } }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      resolve({
        inlineData: {
          data: base64String,
          mimeType: file.type,
        },
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

// Helper: Crop Image from File based on bounding box [ymin, xmin, ymax, xmax] (0-1000)
const cropImageFromFile = async (file: File, box: number[]): Promise<string | undefined> => {
  // Only support auto-cropping for image files
  if (!file || !file.type.startsWith('image/') || !box || box.length !== 4) return undefined;
  
  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    
    img.onload = () => {
      // Gemini detection follows [ymin, xmin, ymax, xmax] normalized to 1000
      const [ymin, xmin, ymax, xmax] = box;
      
      const width = img.width;
      const height = img.height;
      
      // Calculate pixel coordinates from 0-1000 scale
      // Use Math.floor/ceil and Math.max/min to ensure integers and within bounds
      const realX = Math.max(0, Math.floor((xmin / 1000) * width));
      const realY = Math.max(0, Math.floor((ymin / 1000) * height));
      const realW = Math.min(width - realX, Math.ceil(((xmax - xmin) / 1000) * width));
      const realH = Math.min(height - realY, Math.ceil(((ymax - ymin) / 1000) * height));

      if (realW <= 0 || realH <= 0) {
        URL.revokeObjectURL(url);
        resolve(undefined);
        return;
      }

      const canvas = document.createElement('canvas');
      canvas.width = realW;
      canvas.height = realH;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Draw the specific slice
        ctx.drawImage(img, realX, realY, realW, realH, 0, 0, realW, realH);
        
        // Convert to base64
        const data = canvas.toDataURL('image/png');
        URL.revokeObjectURL(url);
        resolve(data);
      } else {
        URL.revokeObjectURL(url);
        resolve(undefined);
      }
    };
    
    img.onerror = (err) => {
        console.error("Failed to load image for cropping", err);
        URL.revokeObjectURL(url);
        resolve(undefined);
    }
    
    img.src = url;
  });
}

// Function to parse questions from Uploaded Document (PDF/Image)
export const generateQuestionsFromDocument = async (file: File): Promise<Question[]> => {
  // Fix: Obtained API key directly from process.env.API_KEY as per instructions.
  // Assumed process.env.API_KEY is pre-configured and accessible.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const filePart = await fileToGenerativePart(file);

  const prompt = `
    Bạn là trợ lý nhập liệu đề thi từ hình ảnh/PDF. Hãy trích xuất câu hỏi từ tài liệu đính kèm.
    
    QUY TẮC NHẬN DIỆN ĐÁP ÁN DỰA TRÊN GẠCH CHÂN (UNDERLINE):
    
    1. PHẦN I (Trắc nghiệm MCQ - 4 chọn 1):
       - Các câu hỏi bắt đầu bằng "Câu 1:", "Câu 2:"...
       - Đáp án đúng là đáp án có CHỮ CÁI (A, B, C, D) được GẠCH CHÂN. 
       - Output Type: 'MCQ'.

    2. PHẦN II (Trắc nghiệm Đúng/Sai):
       - Bắt đầu bằng "Câu [Số]: [Nội dung chung]". Bên trong có các ý a), b), c), d).
       - Hãy tách RIÊNG từng ý a, b, c, d thành các câu hỏi độc lập.
       - Định dạng Text: "Câu [Số]: [Nội dung chung] - ý [a/b/c/d]: [Nội dung riêng]".
       - Output Type: 'TF'.
       - correctAnswer: "Đúng" (nếu gạch chân) hoặc "Sai".

    3. QUY TẮC PHÁT HIỆN HÌNH ẢNH (QUAN TRỌNG):
       - Nếu nội dung câu hỏi có hình ảnh minh họa (đồ thị, sơ đồ, hình vẽ...), hãy:
         1. Đặt "hasImage": true.
         2. Trả về toạ độ bounding box của hình ảnh đó trong "image_bbox".
         3. Định dạng bbox: [ymin, xmin, ymax, xmax] (thang đo chuẩn 1000x1000).
            Ví dụ: [100, 0, 500, 500] nghĩa là hình ảnh bắt đầu từ y=10% đến y=50%, x=0% đến x=50%.
       - "image_bbox" phải bao trùm toàn bộ hình ảnh minh họa và chú thích của nó.

    OUTPUT FORMAT (JSON Array ONLY, NO MARKDOWN):
    [
      {
        "text": "Câu 1: ...",
        "type": "MCQ",
        "options": ["A. ...", "B. ..."],
        "correctAnswer": "A",
        "hasImage": true,
        "image_bbox": [150, 50, 300, 400]
      }
    ]
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview', 
      contents: {
        parts: [filePart, { text: prompt }]
      },
      config: {
        responseMimeType: 'application/json'
      }
    });

    // Clean JSON string rigorously
    let text = response.text || '';
    // Remove markdown code blocks if detected
    text = text.replace(/^```json/, '').replace(/^```/, '').replace(/```$/, '').trim();

    if (!text) return [];

    let rawQuestions;
    try {
        rawQuestions = JSON.parse(text);
    } catch (e) {
        console.error("JSON Parse Error", e);
        console.log("Raw Text:", text);
        return [];
    }

    if (!Array.isArray(rawQuestions)) rawQuestions = [rawQuestions];

    // Process questions and auto-crop images
    const processedQuestions = await Promise.all(rawQuestions.map(async (q: any, index: number) => {
        let imageBase64 = undefined;
        
        // Attempt auto-crop if detected
        if (q.hasImage && Array.isArray(q.image_bbox) && q.image_bbox.length === 4 && file.type.startsWith('image/')) {
            try {
                // Log for debugging
                console.log(`Cropping Q${index} with bbox:`, q.image_bbox);
                imageBase64 = await cropImageFromFile(file, q.image_bbox);
            } catch (e) {
                console.error("Auto-crop failed for Q" + index, e);
            }
        }

        return {
            id: `doc-${Date.now()}-${index}`,
            type: q.type || 'MCQ',
            text: q.text || 'Câu hỏi chưa có nội dung',
            options: q.options || [], 
            correctAnswer: q.correctAnswer || '',
            hasImage: !!q.hasImage,
            image: imageBase64 
        };
    }));

    return processedQuestions;

  } catch (error) {
    console.error("Gemini Document Parsing Error:", error);
    alert("Lỗi phân tích file. Chi tiết trong Console.");
    return [];
  }
};

// NEW: Function to generate Blog Code
export const generateExportCode = async (type: 'THEME' | 'PAGE'): Promise<string> => {
  // Fix: Obtained API key directly from process.env.API_KEY as per instructions.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  let prompt = "";
  
  if (type === 'THEME') {
      prompt = `
      Hãy viết một đoạn mã HTML hoàn chỉnh để làm Theme (Chủ đề) cho Blogspot (Blogger).
      Chủ đề: Website Giáo Dục môn Sinh Học (LMS).
      Yêu cầu:
      1. Sử dụng Tailwind CSS qua CDN.
      2. Giao diện màu xanh lá cây (Green) chủ đạo, hiện đại, Responsive.
      3. Cấu trúc gồm: Header (Logo Sinh Học LMS), Menu (Trang chủ, Thi Online, Tài Liệu), Hero Section giới thiệu, và Grid hiển thị các bài đăng (Post).
      4. Footer ghi "Copyright Nguyễn Hồng Hiển".
      5. Code phải là HTML chuẩn có thể copy paste vào phần "Edit HTML" của Blogspot.
      6. CHỈ TRẢ VỀ MÃ HTML, KHÔNG GIẢI THÍCH GÌ THÊM.
      `;
  } else {
      prompt = `
      Hãy viết một đoạn mã HTML/CSS/JS độc lập (Snippet) để nhúng vào một bài viết trên website/blog.
      Chức năng: Một Widget trắc nghiệm Sinh Học nhỏ (Mini Quiz).
      Yêu cầu:
      1. Có 1 câu hỏi mẫu về Sinh học.
      2. Có 4 đáp án, khi người dùng click vào sẽ hiện Đúng/Sai ngay lập tức.
      3. Giao diện đẹp, bo tròn, sử dụng Tailwind CSS (nếu có thể) hoặc Inline CSS gọn nhẹ.
      4. Code phải đóng gói trong thẻ <div>, có thể copy paste vào bất kỳ trình soạn thảo HTML nào.
      5. CHỈ TRẢ VỀ MÃ HTML, KHÔNG GIẢI THÍCH GÌ THÊM.
      `;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    // Clean up markdown code blocks if present
    let text = response.text || '';
    text = text.replace(/^```html/, '').replace(/^```xml/, '').replace(/```$/, '').trim();
    return text.trim();

  } catch (error) {
    console.error("Generate Code Error:", error);
    return "Đã xảy ra lỗi khi tạo mã. Vui lòng thử lại.";
  }
}
