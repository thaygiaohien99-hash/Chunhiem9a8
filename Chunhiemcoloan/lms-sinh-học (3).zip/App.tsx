import React, { useState, useEffect } from 'react';
import { User, UserRole } from './types';
import { Layout } from './components/Layout';
import { HomeView } from './views/HomeView';
import { TestView } from './views/TestView';
import { BattleView } from './views/BattleView';
import { LeaderboardView } from './views/LeaderboardView';
import { ProfileView } from './views/ProfileView';

// Auth View extracted here for simplicity in file structure
import { AuthView } from './views/AuthView'; 

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('home');
  // State to hold the navigation blocking function
  const [navigationBlocker, setNavigationBlocker] = useState<(() => boolean) | null>(null);

  useEffect(() => {
    // Check session
    const session = localStorage.getItem('current_user_phone');
    if (session) {
      const userData = localStorage.getItem(`user_${session}`);
      if (userData) {
        setUser(JSON.parse(userData));
      }
    }
  }, []);

  const handleLogin = (u: User) => {
    localStorage.setItem('current_user_phone', u.phone);
    localStorage.setItem(`user_${u.phone}`, JSON.stringify(u));
    setUser(u);
    setActiveTab('home');
    setNavigationBlocker(null);
  };

  const checkNavigation = (): boolean => {
    if (navigationBlocker) {
        return navigationBlocker();
    }
    return true;
  };

  const handleLogout = () => {
    if (!checkNavigation()) return;
    localStorage.removeItem('current_user_phone');
    setUser(null);
    setNavigationBlocker(null);
  };

  const handleTabChange = (tab: string) => {
    if (activeTab === tab) return;
    if (!checkNavigation()) return;
    
    setActiveTab(tab);
    // We clear the blocker on successful navigation. 
    // The new view will register its own blocker if needed.
    setNavigationBlocker(null);
  };

  const handleUpdateUser = (updated: User) => {
    setUser(updated);
  };

  if (!user) {
    return <AuthView onLoginSuccess={handleLogin} />;
  }

  return (
    <Layout 
      activeTab={activeTab} 
      onTabChange={handleTabChange} 
      user={user} 
      onLogout={handleLogout}
    >
      {activeTab === 'home' && <HomeView user={user} onNavigate={handleTabChange} />}
      {activeTab === 'test' && (
        <TestView 
            user={user} 
            onUpdateUser={handleUpdateUser} 
            setNavigationBlocker={setNavigationBlocker} 
        />
      )}
      {activeTab === 'battle' && <BattleView user={user} onUpdateUser={handleUpdateUser} />}
      {activeTab === 'leaderboard' && <LeaderboardView />}
      {activeTab === 'profile' && <ProfileView user={user} />}
    </Layout>
  );
};

export default App;