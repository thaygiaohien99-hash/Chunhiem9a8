
import React, { useState } from 'react';
import { User, UserLevel, UserRole } from '../types';
import { calculateLevel, GOOGLE_SCRIPT_URL } from '../services/dataService';
import { generateExportCode } from '../services/geminiService';

interface ProfileViewProps {
  // Fix: changed lowercase 'user' to capitalized 'User' to match the imported type
  user: User;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ user }) => {
  // Admin Export Code State
  const [generatedCode, setGeneratedCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [exportType, setExportType] = useState<'THEME' | 'PAGE' | null>(null);

  // --- ADMIN VIEW: System Configuration & Maintenance ---
  if (user.role === UserRole.ADMIN) {
    const handleClearCache = () => {
      if (confirm('Hành động này sẽ xóa toàn bộ dữ liệu lưu tạm trên trình duyệt (bao gồm phiên đăng nhập). Bạn có chắc chắn?')) {
        localStorage.clear();
        window.location.reload();
      }
    };

    const handleGenerateCode = async (type: 'THEME' | 'PAGE') => {
        setIsGenerating(true);
        setExportType(type);
        setGeneratedCode(''); // Clear old code
        try {
            const code = await generateExportCode(type);
            setGeneratedCode(code);
        } catch (e) {
            alert("Lỗi khi tạo mã");
        } finally {
            setIsGenerating(false);
        }
    };

    const handleCopyCode = () => {
        if (!generatedCode) return;
        navigator.clipboard.writeText(generatedCode);
        alert("Đã sao chép mã vào bộ nhớ tạm!");
    };

    const handleDownloadCode = () => {
        if (!generatedCode) return;
        const blob = new Blob([generatedCode], { type: "text/plain" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.download = exportType === 'THEME' ? "template_lms_blog.xml" : "widget_trac_nghiem.html";
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
    };

    return (
      <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
        {/* Admin Identity Card */}
        <div className="bg-white rounded-2xl shadow-sm p-8 flex flex-col md:flex-row items-center gap-6 border-l-4 border-red-600">
          <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center text-4xl shadow-inner shrink-0">
            🛡️
          </div>
          <div className="text-center md:text-left flex-1">
            <h2 className="text-2xl font-bold text-gray-800">{user.name}</h2>
            <p className="text-gray-500 font-medium mb-2">Quản Trị Viên Hệ Thống</p>
            <span className="inline-block px-3 py-1 bg-red-600 text-white text-xs font-bold rounded uppercase tracking-wider">
              Super Admin
            </span>
          </div>
          <div className="text-right hidden md:block">
            <p className="text-sm text-gray-400">Phiên bản hệ thống</p>
            <p className="font-mono font-bold text-gray-600">v1.2.5 (Stable)</p>
          </div>
        </div>

        {/* Primary Management Button (New Section) */}
        <div className="bg-white rounded-xl shadow-lg p-1 border-t-4 border-emerald-500 overflow-hidden">
          <a 
            href="https://docs.google.com/spreadsheets/d/1A4SzA_KPaR9WmGd3lwpChZ-cO862RkIs6mE5oFcevtA/edit?gid=1484331115#gid=1484331115"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-6 bg-gradient-to-r from-emerald-600 to-teal-600 text-white transition-all hover:scale-[1.01] active:scale-[0.99] group"
          >
            <div className="flex items-center gap-4">
              <span className="text-4xl group-hover:rotate-12 transition-transform">📊</span>
              <div>
                <h3 className="text-xl font-bold">QUẢN LÍ HỆ THỐNG</h3>
                <p className="text-emerald-50 text-sm opacity-80">Truy cập Google Sheet quản lý kết quả học sinh & đề thi</p>
              </div>
            </div>
            <span className="text-2xl group-hover:translate-x-2 transition-transform">➜</span>
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* System Status */}
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 className="font-bold text-lg text-gray-800 mb-4 flex items-center gap-2">
              <span>📡</span> Trạng thái kết nối
            </h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500 mb-1">Máy chủ dữ liệu (Google Apps Script)</p>
                <div className="flex items-center gap-2 bg-green-50 p-3 rounded border border-green-200">
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></div>
                  <span className="text-green-700 font-mono text-xs truncate w-full">
                    {GOOGLE_SCRIPT_URL.substring(0, 45)}...
                  </span>
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">Dịch vụ AI (Gemini)</p>
                <div className="flex items-center gap-2 bg-blue-50 p-3 rounded border border-blue-200">
                  <div className="w-2.5 h-2.5 rounded-full bg-blue-500"></div>
                  <span className="text-blue-700 font-medium text-sm">Đang hoạt động (Flash 2.0)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Maintenance Tools */}
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 className="font-bold text-lg text-gray-800 mb-4 flex items-center gap-2">
              <span>🛠️</span> Bảo trì hệ thống
            </h3>
            <div className="space-y-3">
              <button 
                onClick={() => window.location.reload()}
                className="w-full flex items-center justify-between p-3 rounded hover:bg-gray-50 border border-gray-200 transition text-sm"
              >
                <span className="text-gray-700 font-medium">Làm mới ứng dụng (Reload)</span>
                <span className="text-lg">🔄</span>
              </button>
              
              <button 
                onClick={handleClearCache}
                className="w-full flex items-center justify-between p-3 rounded border-2 border-red-500 text-red-600 hover:bg-red-500 hover:text-white transition font-bold text-sm"
              >
                <span>Xóa Cache & Đăng xuất</span>
                <span className="text-lg">🗑️</span>
              </button>
            </div>
            <p className="text-xs text-gray-400 mt-4 italic">
              * Xóa Cache nếu gặp lỗi dữ liệu cũ hoặc không đồng bộ được máy chủ.
            </p>
          </div>
        </div>

        {/* Export Code Section */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 className="font-bold text-lg text-gray-800 mb-4 flex items-center gap-2">
              <span>📤</span> Xuất Code (AI Generated)
            </h3>
            <p className="text-sm text-gray-500 mb-4">
                Sử dụng AI để tạo mã nguồn trang web hoặc widget tích hợp cho Blogspot.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <button
                    onClick={() => handleGenerateCode('THEME')}
                    disabled={isGenerating}
                    className="p-4 rounded-lg border border-purple-200 bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold flex flex-col items-center gap-2 transition disabled:opacity-50"
                >
                    <span className="text-2xl">🌐</span>
                    <span>Xuất HTML Blog (Theme)</span>
                    <span className="text-[10px] font-normal opacity-70 text-center">Tạo toàn bộ giao diện cho Blogspot</span>
                </button>
                <button
                    onClick={() => handleGenerateCode('PAGE')}
                    disabled={isGenerating}
                    className="p-4 rounded-lg border border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold flex flex-col items-center gap-2 transition disabled:opacity-50"
                >
                    <span className="text-2xl">🧩</span>
                    <span>Xuất HTML Trang Blog</span>
                    <span className="text-[10px] font-normal opacity-70 text-center">Tạo widget/đoạn mã nhúng cho bài viết</span>
                </button>
            </div>

            {isGenerating && (
                <div className="text-center py-8 text-gray-500 animate-pulse font-medium">
                    🤖 AI đang viết mã... vui lòng đợi...
                </div>
            )}

            {!isGenerating && generatedCode && (
                <div className="animate-fade-in space-y-3">
                    <div className="flex justify-between items-center">
                        <span className="text-sm font-bold text-gray-700">
                            Kết quả ({exportType === 'THEME' ? 'Blog Theme' : 'Page Snippet'}):
                        </span>
                        <div className="flex gap-2">
                            <button 
                                onClick={handleCopyCode}
                                className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 rounded text-xs font-bold text-gray-700 border border-gray-300"
                            >
                                📋 Copy
                            </button>
                            <button 
                                onClick={handleDownloadCode}
                                className="px-3 py-1.5 bg-bio-600 hover:bg-bio-700 rounded text-xs font-bold text-white shadow"
                            >
                                ⬇️ Tải (.txt)
                            </button>
                        </div>
                    </div>
                    <textarea 
                        className="w-full h-64 p-3 border border-gray-300 rounded-lg bg-gray-900 text-green-400 font-mono text-xs focus:ring-2 focus:ring-bio-500 outline-none"
                        value={generatedCode}
                        readOnly
                    />
                </div>
            )}
        </div>

        {/* Author Credit */}
        <div className="text-center py-8 opacity-70 hover:opacity-100 transition">
          <p className="text-sm text-gray-500">Hệ thống được vận hành bởi</p>
          <p className="text-lg font-bold text-red-800 mt-1 uppercase tracking-widest">Tác giả Nguyễn Hồng Hiển</p>
          <p className="text-xs text-gray-400 mt-2">© 2024 Sinh Học LMS. BioMaster Version.</p>
        </div>
      </div>
    );
  }

  // --- STUDENT VIEW (Original Logic) ---
  const currentLevel = calculateLevel(user.totalScore, user.examHistory);

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white rounded-2xl shadow p-8 text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-r from-bio-400 to-bio-600 z-0"></div>
        <div className="relative z-10">
          <div className="w-24 h-24 mx-auto bg-white rounded-full p-1 shadow-lg mb-4">
            <div className="w-full h-full bg-gray-200 rounded-full flex items-center justify-center text-4xl">
              🧬
            </div>
          </div>
          <h2 className="text-2xl font-bold text-gray-800">{user.name}</h2>
          <p className="text-gray-500">{user.className || 'Học viên'}</p>
          
          <div className="mt-6 inline-block px-6 py-2 bg-yellow-50 text-yellow-700 rounded-full border border-yellow-200 font-bold">
            {currentLevel}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow p-6">
        <h3 className="font-bold text-lg mb-4 border-b pb-2">Lịch sử làm bài</h3>
        {user.examHistory.length === 0 ? (
          <p className="text-gray-500 italic text-center py-4">Chưa có bài kiểm tra nào.</p>
        ) : (
          <div className="space-y-3">
            {user.examHistory.map((h, i) => (
              <div key={i} className="flex justify-between items-center p-3 bg-gray-50 rounded hover:bg-gray-100 transition">
                <div>
                  <div className="font-medium text-gray-800">{h.examTitle}</div>
                  <div className="text-xs text-gray-400">{new Date(h.date).toLocaleDateString()}</div>
                </div>
                <div className={`font-bold text-lg ${h.score >= 8 ? 'text-green-600' : h.score >= 5 ? 'text-yellow-600' : 'text-red-500'}`}>
                  {h.score}/{h.totalQuestions || 15}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
