import React, { useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { GOOGLE_SCRIPT_URL } from '../services/dataService';

interface AuthViewProps {
  onLoginSuccess: (user: User) => void;
}

export const AuthView: React.FC<AuthViewProps> = ({ onLoginSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  
  // Feedback State
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Form State
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [className, setClassName] = useState('');
  
  // UI State
  const [showPassword, setShowPassword] = useState(false);

  // Clear messages when switching tabs
  useEffect(() => {
    setError(null);
    setSuccess(null);
    setShowPassword(false);
  }, [isLogin]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    
    // Validation
    if (!phone.trim()) { setError('Vui lòng nhập số điện thoại'); return; }
    if (!password.trim()) { setError('Vui lòng nhập mật khẩu'); return; }

    // 1. Check Admin (Hardcoded as requested)
    if (phone === '0966000224' && password === '$Hongphat2022') {
      const adminUser: User = {
        phone,
        name: 'Admin Giáo Viên',
        role: UserRole.ADMIN,
        totalScore: 9999,
        examHistory: []
      };
      onLoginSuccess(adminUser);
      return;
    }

    // 2. Check Google Sheet for Students
    if (!GOOGLE_SCRIPT_URL.includes('http')) {
      setError('Lỗi cấu hình hệ thống: URL máy chủ không hợp lệ.');
      return;
    }

    setIsLoading(true);
    try {
      // Add timestamp to avoid caching login result
      const response = await fetch(`${GOOGLE_SCRIPT_URL}?action=login&phone=${phone}&password=${password}&_t=${Date.now()}`);
      
      if (!response.ok) throw new Error('Network response was not ok');
      
      const data = await response.json();

      if (data.success) {
        if (data.user.status === 'LOCKED') {
          setError('Tài khoản của bạn đã bị khóa. Vui lòng liên hệ giáo viên.');
          setIsLoading(false);
          return;
        }

        const loggedUser: User = {
          phone: data.user.phone,
          name: data.user.name,
          className: data.user.className,
          role: UserRole.STUDENT,
          totalScore: data.user.totalScore || 0,
          examHistory: data.user.examHistory || []
        };
        
        onLoginSuccess(loggedUser);
      } else {
        // Show specific error from server if available, else generic
        setError(data.message || 'Số điện thoại hoặc mật khẩu không chính xác.');
      }
    } catch (error) {
      console.error(error);
      setError('Không thể kết nối đến máy chủ. Vui lòng kiểm tra kết nối mạng.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    // Strict Validation
    if (!name.trim()) { setError('Vui lòng nhập họ tên'); return; }
    if (!className.trim()) { setError('Vui lòng nhập tên lớp'); return; }
    if (phone.length !== 10 || !/^\d+$/.test(phone)) { 
        setError('Số điện thoại không hợp lệ (phải đủ 10 chữ số).'); 
        return; 
    }
    if (password.length < 6) { setError('Mật khẩu phải có ít nhất 6 ký tự.'); return; }

    setIsLoading(true);
    try {
      // FIX: Use text/plain content type to avoid CORS Preflight errors
      const response = await fetch(GOOGLE_SCRIPT_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8',
        },
        body: JSON.stringify({
          action: 'register',
          phone,
          password,
          name,
          className
        })
      });

      if (!response.ok) throw new Error('Network response was not ok');

      const data = await response.json();

      if (data.success) {
        // Auto switch to login view with success message
        setIsLogin(true);
        setSuccess('🎉 Đăng ký thành công! Vui lòng đăng nhập.');
        setPassword(''); // Clear password but keep phone for convenience
      } else {
        setError(data.message || 'Đăng ký thất bại. Số điện thoại có thể đã tồn tại.');
      }
    } catch (error) {
      console.error(error);
      setError('Lỗi kết nối khi đăng ký. Vui lòng thử lại sau.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bio-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden animate-fade-in">
        <div className="bg-bio-600 p-6 text-center text-white">
          <h1 className="text-3xl font-bold mb-2">Sinh Học LMS</h1>
          <p className="text-bio-100">Hệ thống học tập Sinh Học THPT</p>
        </div>

        <div className="flex border-b">
          <button 
            onClick={() => setIsLogin(true)}
            className={`flex-1 py-4 font-semibold text-sm transition-colors ${isLogin ? 'text-bio-600 border-b-2 border-bio-600 bg-bio-50' : 'text-gray-400 hover:bg-gray-50'}`}
          >
            Đăng Nhập
          </button>
          <button 
             onClick={() => setIsLogin(false)}
             className={`flex-1 py-4 font-semibold text-sm transition-colors ${!isLogin ? 'text-bio-600 border-b-2 border-bio-600 bg-bio-50' : 'text-gray-400 hover:bg-gray-50'}`}
          >
            Đăng Ký
          </button>
        </div>

        <div className="p-8">
          {/* Notifications Area */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded-lg flex items-start gap-2 animate-pulse">
              <span>⚠️</span>
              <span>{error}</span>
            </div>
          )}
          {success && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 text-green-700 text-sm rounded-lg flex items-start gap-2">
              <span>✅</span>
              <span>{success}</span>
            </div>
          )}

          {isLogin ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Số điện thoại</label>
                <input 
                  type="text" 
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-bio-500 focus:border-bio-500 outline-none transition"
                  placeholder="09xx..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mật khẩu</label>
                <div className="relative">
                  <input 
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-bio-500 focus:border-bio-500 outline-none transition pr-10"
                    placeholder="******"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5 text-gray-500 hover:text-gray-700 focus:outline-none"
                    tabIndex={-1}
                  >
                    {showPassword ? '🙈' : '👁️'}
                  </button>
                </div>
              </div>
              <button 
                disabled={isLoading}
                className="w-full bg-bio-600 text-white py-3 rounded-lg font-bold hover:bg-bio-700 transition disabled:bg-gray-400 disabled:cursor-not-allowed flex justify-center items-center gap-2"
              >
                {isLoading && <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>}
                {isLoading ? 'Đang xác thực...' : 'Đăng Nhập'}
              </button>
              
              <div className="text-center pt-2">
                <p className="text-xs text-red-700 font-bold opacity-90">
                  Tác giả Nguyễn Hồng Hiển
                </p>
              </div>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Họ và Tên</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-bio-500 outline-none transition"
                  placeholder="Nguyễn Văn A"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Số điện thoại</label>
                  <input 
                    type="text" 
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-bio-500 outline-none transition"
                    placeholder="10 số"
                    maxLength={10}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Lớp</label>
                  <input 
                    type="text" 
                    value={className}
                    onChange={e => setClassName(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-bio-500 outline-none transition"
                    placeholder="12A1"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mật khẩu</label>
                <div className="relative">
                  <input 
                    type={showPassword ? "text" : "password"} 
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-bio-500 outline-none transition pr-10"
                    placeholder="Tối thiểu 6 ký tự"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5 text-gray-500 hover:text-gray-700 focus:outline-none"
                    tabIndex={-1}
                  >
                    {showPassword ? '🙈' : '👁️'}
                  </button>
                </div>
              </div>
              <button 
                disabled={isLoading}
                className="w-full bg-bio-600 text-white py-3 rounded-lg font-bold hover:bg-bio-700 transition disabled:bg-gray-400 disabled:cursor-not-allowed flex justify-center items-center gap-2"
              >
                {isLoading && <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>}
                {isLoading ? 'Đang gửi...' : 'Đăng Ký Tài Khoản'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};