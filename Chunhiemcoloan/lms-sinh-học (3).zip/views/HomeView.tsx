import React, { useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { getExams, fetchCloudLeaderboard } from '../services/dataService';

interface HomeViewProps {
  user: User;
  onNavigate: (tab: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ user, onNavigate }) => {
  const isAdmin = user.role === UserRole.ADMIN;
  const [notifications, setNotifications] = useState<{id: string, type: 'REMINDER' | 'BATTLE', message: string, actionTab: string}[]>([]);
  
  // Admin Stats State
  const [adminStats, setAdminStats] = useState({
    totalExams: 0,
    totalQuestions: 0,
    totalStudents: 0,
    activeBattles: 0
  });

  useEffect(() => {
    const fetchData = async () => {
      const allExams = await getExams();
      
      // Admin Logic: Calculate Dashboard Stats
      if (isAdmin) {
        const leaderboard = await fetchCloudLeaderboard('MONTH'); // Use this to approximate user count
        const activeBattles = allExams.filter(e => e.category === 'BATTLE' && !e.isLocked).length;
        const officialExams = allExams.filter(e => e.category !== 'BATTLE');
        const totalQs = officialExams.reduce((acc, curr) => acc + curr.questions.length, 0);

        setAdminStats({
          totalExams: officialExams.length,
          totalQuestions: totalQs,
          totalStudents: leaderboard.length,
          activeBattles: activeBattles
        });
        return; // Admin doesn't need the student notifications below
      }

      // Student Logic: Notifications
      const notifs: typeof notifications = [];

      // Logic 1: Daily Reminder
      const lastTestDate = user.examHistory.length > 0 
        ? new Date(user.examHistory[0].date).toDateString() 
        : null;
      const today = new Date().toDateString();
      
      if (lastTestDate !== today) {
        notifs.push({
          id: 'daily-reminder',
          type: 'REMINDER',
          message: `📅 Bạn chưa ôn luyện hôm nay! Hãy dành 15 phút để duy trì chuỗi học tập.`,
          actionTab: 'test'
        });
      }

      // Logic 2: Active Battles
      const activeBattles = allExams.filter(e => e.category === 'BATTLE' && !e.isLocked);
      activeBattles.forEach(b => {
        notifs.push({
          id: b.id,
          type: 'BATTLE',
          message: `⚔️ Phòng đấu "${b.title}" đang diễn ra. Tham gia ngay (Mã: ${b.id})!`,
          actionTab: 'battle'
        });
      });

      setNotifications(notifs);
    };

    fetchData();
  }, [user, isAdmin]);

  // --- ADMIN VIEW ---
  if (isAdmin) {
    return (
      <div className="space-y-6 animate-fade-in">
        {/* Admin Header */}
        <div className="bg-gray-800 rounded-2xl p-6 text-white shadow-lg flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold mb-1">Bảng Điều Khiển Quản Trị</h2>
            <p className="text-gray-400 text-sm">Tổng quan hệ thống Sinh Học LMS</p>
          </div>
          <div className="text-4xl">🛠️</div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center justify-center">
            <span className="text-3xl mb-2">📚</span>
            <div className="text-2xl font-bold text-gray-800">{adminStats.totalExams}</div>
            <div className="text-xs text-gray-500 font-semibold uppercase">Đề Thi Chính Thức</div>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center justify-center">
             <span className="text-3xl mb-2">❓</span>
            <div className="text-2xl font-bold text-blue-600">{adminStats.totalQuestions}</div>
            <div className="text-xs text-gray-500 font-semibold uppercase">Ngân Hàng Câu Hỏi</div>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center justify-center">
             <span className="text-3xl mb-2">👥</span>
            <div className="text-2xl font-bold text-green-600">{adminStats.totalStudents}</div>
            <div className="text-xs text-gray-500 font-semibold uppercase">Học Sinh Tham Gia</div>
          </div>
           <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center justify-center">
             <span className="text-3xl mb-2">⚔️</span>
            <div className="text-2xl font-bold text-red-600">{adminStats.activeBattles}</div>
            <div className="text-xs text-gray-500 font-semibold uppercase">Phòng Đấu Đang Mở</div>
          </div>
        </div>

        {/* Management Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <div 
            onClick={() => onNavigate('test')}
            className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition cursor-pointer group"
           >
             <div className="flex items-center gap-4">
                <div className="bg-blue-100 p-4 rounded-full text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition">
                  📝
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-800">Quản Lý Ngân Hàng Đề</h3>
                  <p className="text-sm text-gray-500">Tạo, sửa, xóa đề thi và nội dung câu hỏi.</p>
                </div>
             </div>
           </div>

           <div 
            onClick={() => onNavigate('battle')}
            className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition cursor-pointer group"
           >
             <div className="flex items-center gap-4">
                <div className="bg-red-100 p-4 rounded-full text-red-600 group-hover:bg-red-600 group-hover:text-white transition">
                  🛡️
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-800">Giám Sát Thách Đấu</h3>
                  <p className="text-sm text-gray-500">Xem các phòng đấu, khóa phòng hoặc xóa phòng.</p>
                </div>
             </div>
           </div>
        </div>
        
        {/* System Health (Mock) */}
        <div className="bg-green-50 border border-green-200 p-4 rounded-xl flex items-center gap-3">
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-green-800 text-sm font-medium">Hệ thống đang hoạt động bình thường. Kết nối Google Sheet ổn định.</span>
        </div>
      </div>
    );
  }

  // --- STUDENT VIEW (Unchanged structure) ---
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-bio-600 to-bio-500 rounded-2xl p-6 text-white shadow-lg">
        <h2 className="text-2xl font-bold mb-2">Chào mừng trở lại, {user.name}!</h2>
        <p className="opacity-90">
          Hãy tiếp tục hành trình chinh phục kiến thức Sinh Học hôm nay.
        </p>
      </div>

      {/* Notifications Section */}
      {notifications.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-2">
            <span className="text-xl">🔔</span>
            <h3 className="font-bold text-gray-800">Thông Báo & Nhắc Nhở</h3>
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{notifications.length}</span>
          </div>
          <div className="divide-y divide-gray-50">
            {notifications.map((notif) => (
              <div 
                key={notif.id}
                onClick={() => onNavigate(notif.actionTab)}
                className={`p-4 flex items-center justify-between cursor-pointer transition hover:bg-opacity-80 ${
                  notif.type === 'BATTLE' ? 'bg-red-50 hover:bg-red-100' : 'bg-yellow-50 hover:bg-yellow-100'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${
                    notif.type === 'BATTLE' ? 'bg-red-200 text-red-700' : 'bg-yellow-200 text-yellow-700'
                  }`}>
                    {notif.type === 'BATTLE' ? '⚔️' : '⏰'}
                  </div>
                  <div>
                    <p className={`text-sm font-bold ${
                      notif.type === 'BATTLE' ? 'text-red-800' : 'text-yellow-800'
                    }`}>
                      {notif.type === 'BATTLE' ? 'Sự kiện Thách Đấu' : 'Nhắc nhở học tập'}
                    </p>
                    <p className={`text-sm ${
                      notif.type === 'BATTLE' ? 'text-red-600' : 'text-yellow-700'
                    }`}>
                      {notif.message}
                    </p>
                  </div>
                </div>
                <div className="text-gray-400 text-xl">›</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Navigation Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Card 1 */}
        <div 
          onClick={() => onNavigate('test')}
          className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-100 p-3 rounded-lg text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition">
              📝
            </div>
          </div>
          <h3 className="font-bold text-gray-800 text-lg mb-1">Kiểm tra Online</h3>
          <p className="text-sm text-gray-500">
            Thực hành các bài kiểm tra theo cấp độ.
          </p>
        </div>

        {/* Card 2 */}
        <div 
          onClick={() => onNavigate('battle')}
          className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="bg-red-100 p-3 rounded-lg text-red-600 group-hover:bg-red-600 group-hover:text-white transition">
              ⚔️
            </div>
          </div>
          <h3 className="font-bold text-gray-800 text-lg mb-1">Thách Đấu</h3>
          <p className="text-sm text-gray-500">
            Tranh tài kiến thức với bạn bè trong thời gian thực.
          </p>
        </div>

        {/* Card 3 */}
        <div 
          onClick={() => onNavigate('leaderboard')}
          className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="bg-yellow-100 p-3 rounded-lg text-yellow-600 group-hover:bg-yellow-600 group-hover:text-white transition">
              🏆
            </div>
          </div>
          <h3 className="font-bold text-gray-800 text-lg mb-1">Bảng Xếp Hạng</h3>
          <p className="text-sm text-gray-500">
            Xem thành tích và thứ hạng của bạn trên hệ thống.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow p-6">
        <h3 className="font-bold text-gray-800 mb-4">Thống kê nhanh</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-gray-50 rounded-lg text-center">
            <div className="text-2xl font-bold text-bio-600">{user.totalScore}</div>
            <div className="text-xs text-gray-500 uppercase font-semibold">Tổng Điểm</div>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg text-center">
            <div className="text-2xl font-bold text-purple-600">{user.examHistory.length}</div>
            <div className="text-xs text-gray-500 uppercase font-semibold">Bài Đã Thi</div>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg text-center">
            <div className="text-2xl font-bold text-blue-600">
                {user.examHistory.filter(h => h.score >= 8).length}
            </div>
            <div className="text-xs text-gray-500 uppercase font-semibold">Bài Đạt Giỏi</div>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg text-center">
            <div className="text-2xl font-bold text-orange-600">
              {user.examHistory.length > 0 
                ? Math.round(user.totalScore / user.examHistory.length * 10) / 10 
                : 0}
            </div>
            <div className="text-xs text-gray-500 uppercase font-semibold">Điểm TB</div>
          </div>
        </div>
      </div>
    </div>
  );
};