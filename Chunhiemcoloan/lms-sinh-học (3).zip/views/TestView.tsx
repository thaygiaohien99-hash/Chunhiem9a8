
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { createPortal } from 'react-dom';
import * as XLSX from 'xlsx'; // Import SheetJS
import { User, UserRole, Exam, Question, ExamResult, ExamResultDetail } from '../types';
import { getExams, publishExamToCloud, submitExamResultToCloud, deleteExamFromCloud, getExamParticipants } from '../services/dataService';
import { generateBiologyQuestions, generateQuestionsFromDocument } from '../services/geminiService';

interface TestViewProps {
  user: User;
  onUpdateUser: (updatedUser: User) => void;
  setNavigationBlocker?: React.Dispatch<React.SetStateAction<(() => boolean) | null>>;
}

export const TestView: React.FC<TestViewProps> = ({ user, onUpdateUser, setNavigationBlocker }) => {
  const isAdmin = user.role === UserRole.ADMIN;
  const [exams, setExams] = useState<Exam[]>([]);
  const [activeExam, setActiveExam] = useState<Exam | null>(null);
  const [isLoading, setIsLoading] = useState(true); // Add loading state
  
  // Student State
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [score, setScore] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [startTime, setStartTime] = useState<string>(''); // Track start time for report
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [reviewFilter, setReviewFilter] = useState<'ALL' | 'INCORRECT'>('ALL');
  // New state for submission reason (e.g., timeout)
  const [submissionReason, setSubmissionReason] = useState<string | null>(null);

  // Admin State
  const [isCreating, setIsCreating] = useState(false);
  const [editingExamId, setEditingExamId] = useState<string | null>(null); // Track if editing
  const [newExamTitle, setNewExamTitle] = useState('');
  const [newExamCategory, setNewExamCategory] = useState<Exam['category']>('Sinh 12');
  const [newExamDuration, setNewExamDuration] = useState<number>(45); // Default 45 mins
  const [parsedQuestions, setParsedQuestions] = useState<Question[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string>('');
  const [isSavingExam, setIsSavingExam] = useState(false);

  // Admin Result Viewing State
  const [viewingResultExam, setViewingResultExam] = useState<Exam | null>(null);
  const [examResultsData, setExamResultsData] = useState<any[]>([]);
  const [isLoadingResults, setIsLoadingResults] = useState(false);
  const [selectedStudentResult, setSelectedStudentResult] = useState<any | null>(null); // For detailed modal
  const [adminDetailFilter, setAdminDetailFilter] = useState<'ALL' | 'INCORRECT'>('ALL'); // New filter state

  // Admin Search & Filter State
  const [adminSearchTerm, setAdminSearchTerm] = useState('');
  const [adminCategoryFilter, setAdminCategoryFilter] = useState<string>('ALL');

  // Helper to load and filter exams
  const loadExams = async () => {
    setIsLoading(true);
    try {
        const data = await getExams();
        // Filter out BATTLE exams, only show standard tests
        setExams(data.filter(e => e.category !== 'BATTLE'));
    } catch (error) {
        console.error("Failed to load exams", error);
    } finally {
        setIsLoading(false);
    }
  };

  useEffect(() => {
    loadExams();
  }, []);

  // Timer Logic
  useEffect(() => {
    let timer: any;
    if (activeExam && timeLeft > 0 && score === null) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && activeExam && score === null) {
      handleSubmitExam(true); // Auto submit when time runs out (pass true)
    }
    return () => clearInterval(timer);
  }, [timeLeft, activeExam, score]);

  // --- NAVIGATION BLOCKER LOGIC ---
  const blocker = useCallback(() => {
    return window.confirm('⚠️ Cảnh báo: Bạn đang làm bài thi!\n\nNếu rời đi bây giờ, toàn bộ kết quả sẽ bị mất. Bạn có chắc chắn muốn thoát?');
  }, []);

  const hasProgress = Object.keys(answers).length > 0;

  useEffect(() => {
    if (!setNavigationBlocker) return;

    const isTakingExam = activeExam !== null && score === null;

    if (isTakingExam && hasProgress) {
        // Set app-level blocker
        setNavigationBlocker(() => blocker);

        // Set browser-level blocker (refresh/close)
        const handleBeforeUnload = (e: BeforeUnloadEvent) => {
            e.preventDefault();
            e.returnValue = '';
        };
        window.addEventListener('beforeunload', handleBeforeUnload);

        return () => {
            window.removeEventListener('beforeunload', handleBeforeUnload);
            // We rely on parent to clear blocker on nav success, or we update it when deps change
        };
    } else {
        setNavigationBlocker(null);
    }
  }, [activeExam, score, hasProgress, setNavigationBlocker, blocker]);

  const handleStartExam = (exam: Exam) => {
    setActiveExam(exam);
    setAnswers({});
    setScore(null);
    setTimeLeft(exam.duration * 60);
    setStartTime(new Date().toISOString()); // Capture start time
    setReviewFilter('ALL');
    setSubmissionReason(null); // Reset reason
  };

  const handleExitExam = () => {
     if (score === null && hasProgress) {
         if (!blocker()) return;
     }
     setActiveExam(null);
     setScore(null);
     setAnswers({});
     setTimeLeft(0);
     setStartTime('');
     setSubmissionReason(null);
  };

  const handleAnswer = (qId: string, val: string) => {
    setAnswers(prev => ({ ...prev, [qId]: val }));
  };

  // Modified to accept optional autoSubmit flag
  const handleSubmitExam = async (isAuto: boolean = false) => {
    if (!activeExam) return;
    setIsSubmitting(true);
    
    // Set submission reason if auto
    if (isAuto === true) {
        setSubmissionReason("Đã hết thời gian làm bài! Hệ thống đã tự động nộp bài làm của bạn.");
    } else {
        setSubmissionReason(null);
    }

    const endTime = new Date().toISOString();
    
    // Calculate Score locally & Prepare Detailed Report
    let correctCount = 0;
    const detailedAnswers: ExamResultDetail[] = [];

    activeExam.questions.forEach(q => {
      const userAnswer = answers[q.id]?.trim() || ''; // Handle skipped questions
      const correct = q.correctAnswer?.trim() || '';
      
      // Normalize comparison (case insensitive for text inputs if any, though MCQ is fixed)
      const isCorrect = userAnswer.toUpperCase() === correct.toUpperCase();
      
      if (isCorrect) {
        correctCount++;
      }

      detailedAnswers.push({
        questionId: q.id,
        questionText: q.text,
        userAnswer: userAnswer || '(Bỏ trống)',
        correctAnswer: correct,
        isCorrect: isCorrect
      });
    });

    const finalScore = correctCount; 
    setScore(finalScore);

    const newResult: ExamResult = {
      examId: activeExam.id,
      examTitle: activeExam.title,
      score: finalScore,
      date: endTime,
      startTime: startTime,
      endTime: endTime,
      detailedAnswers: detailedAnswers // Send details to Cloud
    };
    
    // Submit to Cloud
    const result = await submitExamResultToCloud(user.phone, newResult);
    
    if (result.success && result.updatedUser) {
        onUpdateUser(result.updatedUser);
    } else {
        // Only alert error if it's not a timeout (timeout warning is already shown via UI)
        if (!isAuto) alert("Kết quả đã lưu tạm thời nhưng chưa đồng bộ được với máy chủ.");
        
        // Still update local state to show result
        const updatedUser = {
            ...user,
            totalScore: user.totalScore + finalScore,
            examHistory: [newResult, ...user.examHistory]
        };
        onUpdateUser(updatedUser);
    }
    setIsSubmitting(false);
  };

  // --- Admin Handlers ---

  const openNewEditor = () => {
    setIsCreating(true);
    setEditingExamId(null);
    setNewExamTitle('');
    setNewExamCategory('Sinh 12');
    setNewExamDuration(45);
    setParsedQuestions([]);
    setUploadStatus('');
  };

  const closeEditor = () => {
    setIsCreating(false);
    setEditingExamId(null);
  };

  // Helper: Convert File to Base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsGenerating(true);
    setUploadStatus('Đang tải và xử lý file...');
    try {
      const questions = await generateQuestionsFromDocument(file);
      if (questions.length > 0) {
        setParsedQuestions(prev => [...prev, ...questions]);
        setUploadStatus(`Đã trích xuất thành công ${questions.length} câu hỏi.`);
      } else {
        setUploadStatus('Không tìm thấy câu hỏi hoặc lỗi định dạng.');
      }
    } catch (error) {
      console.error(error);
      setUploadStatus('Lỗi khi xử lý file.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCreateWithAI = async () => {
    const topic = prompt('Nhập chủ đề cụ thể (Ví dụ: Di truyền học Mendel):', newExamCategory);
    if (!topic) return;

    setIsGenerating(true);
    setUploadStatus('AI đang soạn câu hỏi...');
    try {
      const questions = await generateBiologyQuestions(topic, 5); // Default 5 for demo
      if (questions.length > 0) {
        setParsedQuestions(prev => [...prev, ...questions]);
        setUploadStatus(`AI đã tạo thêm ${questions.length} câu hỏi.`);
      } else {
        setUploadStatus('AI không trả về kết quả. Thử lại sau.');
      }
    } catch (error) {
       console.error(error);
       setUploadStatus('Lỗi kết nối AI.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleQuestionImageUpload = async (index: number, file?: File) => {
    if (!file) return;
    try {
        const base64 = await fileToBase64(file);
        setParsedQuestions(prev => {
            const newQs = [...prev];
            newQs[index] = { ...newQs[index], image: base64 };
            return newQs;
        });
    } catch (e) {
        console.error("Error reading image file", e);
        alert("Lỗi đọc file ảnh");
    }
  };

  const saveNewExam = async () => {
    if (!newExamTitle || parsedQuestions.length === 0) {
      alert('Vui lòng nhập tên đề thi và phải có ít nhất 1 câu hỏi.');
      return;
    }

    setIsSavingExam(true);
    
    const examData: Exam = {
      id: editingExamId || Date.now().toString(),
      title: newExamTitle,
      category: newExamCategory,
      duration: newExamDuration,
      questions: parsedQuestions,
      createdBy: user.name,
      createdAt: new Date().toISOString()
    };

    const success = await publishExamToCloud(examData);
    
    if (success) {
      alert(editingExamId ? 'Cập nhật thành công!' : 'Tạo đề mới thành công!');
      // Refresh list locally
      if (editingExamId) {
        setExams(prev => prev.map(e => e.id === examData.id ? examData : e));
      } else {
        setExams(prev => [examData, ...prev]);
      }
      closeEditor();
    } else {
      alert('Lỗi khi lưu đề thi. Vui lòng thử lại.');
    }
    setIsSavingExam(false);
  };

  const handleEditExam = (exam: Exam) => {
    setEditingExamId(exam.id);
    setNewExamTitle(exam.title);
    setNewExamCategory(exam.category);
    setNewExamDuration(exam.duration);
    setParsedQuestions(exam.questions);
    setIsCreating(true);
    setUploadStatus('');
  };

  const handleDeleteExam = async (examId: string) => {
    if (!confirm('Bạn có chắc chắn muốn xóa đề thi này?')) return;
    
    // Optimistic update
    setExams(prev => prev.filter(e => e.id !== examId));
    
    await deleteExamFromCloud(examId);
  };

  const handleViewResults = async (exam: Exam) => {
    setViewingResultExam(exam);
    setExamResultsData([]);
    setIsLoadingResults(true);
    try {
        const data = await getExamParticipants(exam.id);
        setExamResultsData(data);
    } catch (e) {
        console.error("Failed to load results", e);
        alert("Không tải được kết quả.");
    } finally {
        setIsLoadingResults(false);
    }
  };

  const handleExportStudentExcel = () => {
    if (!selectedStudentResult || !viewingResultExam) return;

    const data = selectedStudentResult.detailedAnswers?.map((ans: any, idx: number) => ({
      "STT": idx + 1,
      "Câu hỏi": ans.questionText,
      "Học sinh chọn": ans.userAnswer,
      "Đáp án đúng": ans.correctAnswer,
      "Kết quả": ans.isCorrect ? "Đúng" : "Sai"
    }));

    if (!data || data.length === 0) {
      alert("Không có dữ liệu chi tiết để xuất.");
      return;
    }

    // Include header info
    const headerInfo = [
       { "STT": "Họ tên:", "Câu hỏi": selectedStudentResult.name },
       { "STT": "Lớp:", "Câu hỏi": selectedStudentResult.className },
       { "STT": "Bài thi:", "Câu hỏi": viewingResultExam.title },
       { "STT": "Điểm:", "Câu hỏi": `${selectedStudentResult.score}/${viewingResultExam.questions.length}` },
       { "STT": "Bắt đầu:", "Câu hỏi": selectedStudentResult.startTime ? new Date(selectedStudentResult.startTime).toLocaleString('vi-VN') : 'N/A' },
       { "STT": "Kết thúc:", "Câu hỏi": selectedStudentResult.endTime ? new Date(selectedStudentResult.endTime).toLocaleString('vi-VN') : 'N/A' },
       { "STT": "" } // Empty row separator
    ];

    const finalData = [...headerInfo, ...data];

    const worksheet = XLSX.utils.json_to_sheet(finalData, { skipHeader: false });
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "KetQuaChiTiet");
    
    // Adjust column widths roughly
    worksheet['!cols'] = [{ wch: 5 }, { wch: 50 }, { wch: 15 }, { wch: 15 }, { wch: 10 }];

    XLSX.writeFile(workbook, `KetQua_${selectedStudentResult.name.replace(/\s+/g, '_')}_${viewingResultExam.id}.xlsx`);
  };

  const handleExportParticipantList = () => {
    if (!examResultsData || examResultsData.length === 0 || !viewingResultExam) {
        alert("Chưa có dữ liệu để xuất.");
        return;
    }

    const data = examResultsData.map((res, idx) => ({
      "STT": idx + 1,
      "Họ và Tên": res.name,
      "Lớp": res.className,
      "Điểm số": res.score,
      "Tổng câu": viewingResultExam.questions.length,
      "Trạng thái": res.score >= (viewingResultExam.questions.length / 2) ? "Đạt" : "Trượt",
      "Ngày nộp bài": new Date(res.date).toLocaleString('vi-VN')
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "KetQua");
    
    // Auto fit columns roughly
    worksheet['!cols'] = [
        { wch: 5 }, { wch: 25 }, { wch: 10 }, { wch: 10 }, { wch: 10 }, { wch: 10 }, { wch: 22 }
    ];

    XLSX.writeFile(workbook, `DanhSach_ThamGia_${viewingResultExam.id}.xlsx`);
  };

  // --- Filtered Exams Logic ---
  const filteredExams = useMemo(() => {
    if (!isAdmin) return exams;
    
    return exams.filter(exam => {
        const matchesSearch = exam.title.toLowerCase().includes(adminSearchTerm.toLowerCase()) || 
                              exam.id.includes(adminSearchTerm);
        const matchesCategory = adminCategoryFilter === 'ALL' || exam.category === adminCategoryFilter;
        return matchesSearch && matchesCategory;
    });
  }, [exams, isAdmin, adminSearchTerm, adminCategoryFilter]);

  // --- Grouping Logic for Rendering ---
  const groupedQuestions = useMemo(() => {
    if (!activeExam) return [];
    
    const groups: { type: 'SINGLE' | 'GROUP_TF', questions: Question[], title?: string }[] = [];
    let currentTFGroup: Question[] = [];
    let currentTFContext = '';

    const processContext = (text: string) => {
      const parts = text.split(/- ý\s+[a-d]:?/i);
      return parts.length > 1 ? parts[0].trim() : text;
    };

    activeExam.questions.forEach((q) => {
      if (q.type === 'TF') {
        const context = processContext(q.text);
        if (currentTFGroup.length > 0 && currentTFContext === context) {
          currentTFGroup.push(q);
        } else {
          if (currentTFGroup.length > 0) {
            groups.push({ type: 'GROUP_TF', questions: currentTFGroup, title: currentTFContext });
          }
          currentTFGroup = [q];
          currentTFContext = context;
        }
      } else {
        if (currentTFGroup.length > 0) {
            groups.push({ type: 'GROUP_TF', questions: currentTFGroup, title: currentTFContext });
            currentTFGroup = [];
            currentTFContext = '';
        }
        groups.push({ type: 'SINGLE', questions: [q] });
      }
    });

    if (currentTFGroup.length > 0) {
      groups.push({ type: 'GROUP_TF', questions: currentTFGroup, title: currentTFContext });
    }

    return groups;
  }, [activeExam]);

  // --- Render ---

  if (activeExam) {
    // Portal the timer to the main Header
    const portalTarget = document.getElementById('header-timer-portal');
    const timerDisplay = score === null && timeLeft > 0 && portalTarget 
        ? createPortal(
            <div className={`bg-white px-4 py-1.5 rounded-lg shadow-sm border-2 font-mono font-bold text-lg pointer-events-auto transition-all ${
                 timeLeft <= 60 
                 ? 'border-red-500 text-red-600 animate-pulse' 
                 : 'border-white text-bio-700'
            }`}>
               {Math.floor(timeLeft / 60)}:{String(timeLeft % 60).padStart(2, '0')}
            </div>,
            portalTarget
          )
        : null;

    return (
      <div className="-mt-4 -mx-4 md:-mt-8 md:-mx-8">
        {timerDisplay}
        
        {/* Sticky Header - Title Only */}
        <div className="sticky top-0 z-30 bg-white shadow-md border-b border-gray-200 px-4 py-3 md:px-8">
          <div className="max-w-4xl mx-auto flex justify-between items-center">
            <div className="flex items-center gap-4">
                <div>
                    <h2 className="text-xl font-bold text-gray-800">{activeExam.title}</h2>
                    <p className="text-sm text-gray-500">Thời gian: {activeExam.duration} phút</p>
                </div>
                {/* Manual Exit Button */}
                {score === null && (
                    <button 
                        onClick={handleExitExam}
                        className="px-3 py-1 bg-gray-100 hover:bg-red-50 text-gray-600 hover:text-red-600 rounded border border-gray-300 hover:border-red-200 text-sm font-semibold transition"
                    >
                        Thoát
                    </button>
                )}
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="max-w-4xl mx-auto p-4 md:p-8">
            {score !== null ? (
              <div className="bg-white p-6 rounded-xl shadow animate-fade-in">
                <div className="text-center py-10 border-b border-gray-100 mb-6">
                  <h3 className="text-3xl font-bold mb-4 text-gray-800">Kết Quả</h3>
                  
                  {/* Warning if submitted automatically */}
                  {submissionReason && (
                    <div className="mb-6 mx-auto max-w-lg bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-center gap-3 text-left">
                        <span className="text-2xl">⏰</span>
                        <div>
                            <p className="text-yellow-800 font-bold text-sm">Thông báo</p>
                            <p className="text-yellow-700 text-sm">{submissionReason}</p>
                        </div>
                    </div>
                  )}

                  <div className={`text-6xl font-bold mb-4 ${
                    score >= activeExam.questions.length * 0.8 ? 'text-green-600' : 
                    score >= activeExam.questions.length * 0.5 ? 'text-yellow-600' : 'text-red-600'
                  }`}>
                    {score}/{activeExam.questions.length}
                  </div>
                  <p className="text-gray-500 mb-6">Kết quả chi tiết đã được gửi về hệ thống.</p>
                  <button onClick={() => setActiveExam(null)} className="bg-gray-800 text-white px-6 py-2 rounded-lg hover:bg-gray-900 transition">Quay về danh sách</button>
                </div>

                {/* Review Section */}
                <div className="mt-4">
                  <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                    <h4 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                      <span>🔍</span> Xem lại chi tiết bài làm
                    </h4>
                    <div className="flex gap-2 bg-gray-100 p-1 rounded-lg">
                      <button 
                        onClick={() => setReviewFilter('ALL')}
                        className={`px-4 py-1.5 rounded-md text-sm font-bold transition ${reviewFilter === 'ALL' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                      >
                        Tất cả
                      </button>
                      <button 
                        onClick={() => setReviewFilter('INCORRECT')}
                        className={`px-4 py-1.5 rounded-md text-sm font-bold transition ${reviewFilter === 'INCORRECT' ? 'bg-white text-red-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                      >
                        Chỉ câu sai
                      </button>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {activeExam.questions
                      .filter(q => reviewFilter === 'ALL' || answers[q.id] !== q.correctAnswer)
                      .map((q, idx) => {
                      const userAns = answers[q.id];
                      const isCorrect = userAns === q.correctAnswer;
                      const isSkipped = !userAns;
                      const originalIndex = activeExam.questions.findIndex(oq => oq.id === q.id) + 1;
                      
                      return (
                        <div key={idx} className={`p-5 border-l-4 rounded-lg shadow-sm bg-gray-50 ${isCorrect ? 'border-green-500' : 'border-red-500'}`}>
                          <div className="flex justify-between items-start mb-3">
                            <span className="font-bold text-gray-800 text-lg">Câu {originalIndex}:</span>
                            <span className={`text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide ${isCorrect ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                              {isCorrect ? 'Chính xác' : isSkipped ? 'Bỏ qua' : 'Sai'}
                            </span>
                          </div>
                          {q.image && (
                            <div className="mb-4">
                              <img src={q.image} alt="Question Illustration" className="max-w-full h-auto max-h-60 rounded border border-gray-200 block" />
                            </div>
                          )}
                          <p className="text-gray-700 mb-4 font-medium leading-relaxed">{q.text}</p>
                          
                          <div className="grid grid-cols-1 gap-2">
                            {q.options.map((opt, i) => {
                               let optLabel = '';
                               if (q.type === 'MCQ') {
                                 optLabel = ['A', 'B', 'C', 'D'][i]; 
                               } else {
                                 optLabel = opt;
                               }
                               
                               const isSelected = userAns === optLabel;
                               const isTheCorrectAnswer = q.correctAnswer === optLabel;
                               
                               let styleClass = "border-gray-200 bg-white text-gray-600";
                               
                               if (isTheCorrectAnswer) {
                                 styleClass = "border-green-500 bg-green-50 text-green-800 font-bold ring-1 ring-green-500";
                               } else if (isSelected && !isTheCorrectAnswer) {
                                 styleClass = "border-red-500 bg-red-50 text-red-800 ring-1 ring-red-500";
                               } else if (isSelected && isTheCorrectAnswer) {
                                  styleClass = "border-green-500 bg-green-50 text-green-800 font-bold";
                               }

                               return (
                                 <div key={i} className={`p-3 rounded border text-sm flex items-center justify-between transition ${styleClass}`}>
                                    <span className="flex items-center gap-2">
                                      {q.type === 'MCQ' && <span className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-xs font-bold border border-gray-300">{optLabel}</span>}
                                      {opt.replace(/^[A-D]\.\s*/, '')}
                                    </span>
                                    {isTheCorrectAnswer && <span className="text-xs font-bold flex items-center gap-1">✅ Đáp án đúng</span>}
                                    {isSelected && !isTheCorrectAnswer && <span className="text-xs font-bold flex items-center gap-1">❌ Bạn chọn</span>}
                                 </div>
                               )
                            })}
                          </div>
                        </div>
                      )
                    })}
                    {reviewFilter === 'INCORRECT' && activeExam.questions.filter(q => answers[q.id] !== q.correctAnswer).length === 0 && (
                      <div className="text-center py-8 text-gray-500 italic">
                        Xuất sắc! Bạn không làm sai câu nào.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white p-6 rounded-xl shadow space-y-8">
                {groupedQuestions.map((group, groupIdx) => {
                  if (group.type === 'SINGLE') {
                    const q = group.questions[0];
                    return (
                      <div key={q.id} className="p-4 border border-gray-100 rounded-lg bg-gray-50">
                        <p className="font-semibold text-lg mb-3">
                          <span className="text-bio-600 mr-2">Câu {q.id.split('-').pop() ? parseInt(q.id.split('-').pop()!) + 1 : groupIdx + 1}:</span>
                          {q.text}
                        </p>
                        {q.image && (
                           <div className="mb-4 flex justify-center">
                             <img src={q.image} alt="Question Illustration" className="max-w-full h-auto max-h-64 rounded border border-gray-200" />
                           </div>
                        )}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {q.options.map((opt, optIdx) => {
                             const label = ['A', 'B', 'C', 'D'][optIdx] || '';
                             const valToStore = label;
                             const isSelected = answers[q.id] === valToStore;
                             return (
                               <button
                                type="button"
                                key={optIdx}
                                onClick={() => handleAnswer(q.id, valToStore)}
                                className={`text-left p-3 rounded border transition flex items-center ${
                                  isSelected ? 'bg-bio-100 border-bio-500 text-bio-800 ring-1 ring-bio-500' : 'bg-white border-gray-200 hover:border-bio-300'
                                }`}
                               >
                                 <span className="font-bold mr-2 w-6 shrink-0">{label}.</span>
                                 <span>{opt.replace(/^[A-D]\.\s*/, '')}</span>
                               </button>
                             )
                          })}
                        </div>
                      </div>
                    );
                  } else {
                    return (
                      <div key={groupIdx} className="p-5 border border-gray-200 rounded-xl bg-white shadow-sm">
                         <h3 className="font-bold text-lg text-gray-800 mb-4">{group.title || 'Câu hỏi Đúng/Sai'}</h3>
                         <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                               <thead>
                                  <tr className="border-b-2 border-gray-100">
                                     <th className="text-left py-2 px-2 text-gray-500 font-semibold w-2/3">Phát biểu</th>
                                     <th className="text-center py-2 px-2 text-gray-500 font-semibold w-20">Đúng</th>
                                     <th className="text-center py-2 px-2 text-gray-500 font-semibold w-20">Sai</th>
                                  </tr>
                               </thead>
                               <tbody className="divide-y divide-gray-50">
                                  {group.questions.map((q) => {
                                     const match = q.text.match(/- ý\s+[a-d]:?\s*(.*)/i);
                                     const subText = match ? match[1] : q.text;
                                     const userAnswer = answers[q.id];

                                     return (
                                        <tr key={q.id} className="hover:bg-gray-50 transition">
                                           <td className="py-3 px-2 align-middle text-gray-700">
                                              {subText}
                                           </td>
                                           <td className="py-3 px-2 text-center align-middle">
                                              <div 
                                                onClick={() => handleAnswer(q.id, 'Đúng')}
                                                className={`w-6 h-6 rounded-full border-2 mx-auto cursor-pointer flex items-center justify-center transition ${userAnswer === 'Đúng' ? 'border-bio-600 bg-bio-600' : 'border-gray-300'}`}
                                              >
                                                 {userAnswer === 'Đúng' && <div className="w-2.5 h-2.5 bg-white rounded-full" />}
                                              </div>
                                           </td>
                                           <td className="py-3 px-2 text-center align-middle">
                                              <div 
                                                onClick={() => handleAnswer(q.id, 'Sai')}
                                                className={`w-6 h-6 rounded-full border-2 mx-auto cursor-pointer flex items-center justify-center transition ${userAnswer === 'Sai' ? 'border-bio-600 bg-bio-600' : 'border-gray-300'}`}
                                              >
                                                 {userAnswer === 'Sai' && <div className="w-2.5 h-2.5 bg-white rounded-full" />}
                                              </div>
                                           </td>
                                        </tr>
                                     )
                                  })}
                               </tbody>
                            </table>
                         </div>
                      </div>
                    )
                  }
                })}

                <div className="flex justify-end pt-6">
                  <button 
                    type="button"
                    onClick={() => handleSubmitExam(false)}
                    disabled={isSubmitting}
                    className="bg-bio-600 hover:bg-bio-700 text-white px-8 py-3 rounded-lg font-bold shadow-lg transform transition active:scale-95 disabled:bg-gray-400"
                  >
                    {isSubmitting ? 'Đang nộp...' : 'Nộp Bài'}
                  </button>
                </div>
              </div>
            )}
        </div>
      </div>
    );
  }

  // Admin Views & List View
  return (
    <div className="space-y-6">
      {/* Detailed Student Result Modal (Level 2 Modal) */}
      {selectedStudentResult && viewingResultExam && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[60] flex items-center justify-center p-4 animate-fade-in">
           <div className="bg-white w-full max-w-5xl max-h-[95vh] rounded-xl flex flex-col shadow-2xl">
              <div className="p-4 border-b flex justify-between items-center bg-gray-50 rounded-t-xl">
                 <div>
                    <h3 className="text-xl font-bold text-gray-800">📝 Chi tiết bài làm: {selectedStudentResult.name}</h3>
                    <p className="text-sm text-gray-500">Lớp: {selectedStudentResult.className} | Đề: {viewingResultExam.title}</p>
                 </div>
                 <button 
                    onClick={() => setSelectedStudentResult(null)}
                    className="text-gray-400 hover:text-gray-600 w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-200 text-2xl"
                 >
                    &times;
                 </button>
              </div>

              <div className="p-4 bg-blue-50 border-b border-blue-100 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500 block text-xs uppercase font-bold">Điểm số</span>
                    <span className="text-xl font-bold text-blue-700">{selectedStudentResult.score}/{viewingResultExam.questions.length}</span>
                  </div>
                  <div>
                     <span className="text-gray-500 block text-xs uppercase font-bold">Bắt đầu</span>
                     <span className="font-mono text-gray-800">
                        {selectedStudentResult.startTime ? new Date(selectedStudentResult.startTime).toLocaleTimeString('vi-VN') : '--:--'}
                        <br/><span className="text-xs text-gray-400">{selectedStudentResult.startTime ? new Date(selectedStudentResult.startTime).toLocaleDateString('vi-VN') : ''}</span>
                     </span>
                  </div>
                  <div>
                     <span className="text-gray-500 block text-xs uppercase font-bold">Kết thúc</span>
                     <span className="font-mono text-gray-800">
                        {selectedStudentResult.endTime ? new Date(selectedStudentResult.endTime).toLocaleTimeString('vi-VN') : '--:--'}
                     </span>
                  </div>
                  <div className="flex items-center justify-end">
                     <button 
                        onClick={handleExportStudentExcel}
                        className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded flex items-center gap-2 font-bold shadow-sm transition"
                     >
                        <span>📊</span> Tải Excel (.xlsx)
                     </button>
                  </div>
              </div>

              {/* NEW FILTER TOOLBAR */}
              <div className="px-4 py-2 border-b border-gray-100 flex justify-between items-center bg-white">
                  <div className="text-sm font-bold text-gray-700">Chi tiết câu trả lời:</div>
                  <div className="flex gap-2 bg-gray-100 p-1 rounded-lg">
                      <button 
                          onClick={() => setAdminDetailFilter('ALL')}
                          className={`px-3 py-1.5 rounded text-xs font-bold transition ${adminDetailFilter === 'ALL' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                      >
                          Tất cả
                      </button>
                      <button 
                          onClick={() => setAdminDetailFilter('INCORRECT')}
                          className={`px-3 py-1.5 rounded text-xs font-bold transition ${adminDetailFilter === 'INCORRECT' ? 'bg-white text-red-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                      >
                          Chỉ câu sai
                      </button>
                  </div>
              </div>

              <div className="flex-1 overflow-y-auto p-0">
                 <table className="w-full text-sm text-left border-collapse">
                    <thead className="bg-gray-100 text-gray-600 sticky top-0 z-10 shadow-sm">
                       <tr>
                          <th className="px-4 py-3 border-b w-12 text-center">#</th>
                          <th className="px-4 py-3 border-b">Câu hỏi</th>
                          <th className="px-4 py-3 border-b w-32">HS Chọn</th>
                          <th className="px-4 py-3 border-b w-32">Đáp Án</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                       {(selectedStudentResult.detailedAnswers || [])
                          .map((ans: any, idx: number) => ({...ans, originalIndex: idx + 1})) // Preserve index
                          .filter((ans: any) => adminDetailFilter === 'ALL' || !ans.isCorrect) // Filter
                          .map((ans: any, idx: number) => {
                              const isCorrect = ans.isCorrect;
                              return (
                                 <tr key={idx} className={`hover:bg-gray-50 transition ${!isCorrect ? 'bg-red-50' : ''}`}>
                                    <td className="px-4 py-3 text-center text-gray-500">{ans.originalIndex}</td>
                                    <td className="px-4 py-3 text-gray-800 font-medium">
                                       {ans.questionText}
                                    </td>
                                    <td className={`px-4 py-3 font-bold ${!isCorrect ? 'text-red-600' : 'text-gray-600'}`}>
                                       {ans.userAnswer || '(Bỏ trống)'}
                                    </td>
                                    <td className="px-4 py-3 font-bold text-green-700">
                                       {ans.correctAnswer}
                                    </td>
                                 </tr>
                              )
                       })}
                       {(!selectedStudentResult.detailedAnswers || selectedStudentResult.detailedAnswers.length === 0) && (
                          <tr><td colSpan={4} className="p-8 text-center text-gray-400">Không có dữ liệu chi tiết.</td></tr>
                       )}
                    </tbody>
                 </table>
              </div>
           </div>
        </div>
      )}

      {/* Result Viewing Modal (Level 1 Modal) */}
      {viewingResultExam && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white w-full max-w-4xl max-h-[90vh] rounded-xl flex flex-col shadow-2xl">
            <div className="p-4 border-b flex justify-between items-center bg-gray-50 rounded-t-xl">
              <div>
                <h3 className="text-xl font-bold text-gray-800">📊 Kết quả thi: {viewingResultExam.title}</h3>
                <p className="text-xs text-gray-500">Mã đề: {viewingResultExam.id}</p>
              </div>
              <button 
                onClick={() => setViewingResultExam(null)}
                className="text-gray-400 hover:text-gray-600 w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-200 text-2xl"
              >
                &times;
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6">
              {isLoadingResults ? (
                <div className="text-center py-10">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-bio-200 border-t-bio-600 mb-2"></div>
                  <p className="text-gray-500">Đang tải dữ liệu...</p>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                    <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 text-center">
                      <div className="text-2xl font-bold text-blue-600">{examResultsData.length}</div>
                      <div className="text-xs text-blue-800 font-semibold uppercase">Tổng lượt tham gia</div>
                    </div>
                    <div className="bg-green-50 p-3 rounded-lg border border-green-100 text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {examResultsData.length > 0 
                          ? (examResultsData.reduce((acc, curr) => acc + curr.score, 0) / examResultsData.length).toFixed(1)
                          : 0}
                      </div>
                      <div className="text-xs text-green-800 font-semibold uppercase">Điểm trung bình</div>
                    </div>
                     <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-100 text-center">
                      <div className="text-2xl font-bold text-yellow-600">
                        {examResultsData.reduce((acc, curr) => curr.score >= (viewingResultExam.questions.length / 2) ? acc + 1 : acc, 0)}
                      </div>
                      <div className="text-xs text-yellow-800 font-semibold uppercase">Số lượng đạt</div>
                    </div>
                     <div className="bg-red-50 p-3 rounded-lg border border-red-100 text-center">
                      <div className="text-2xl font-bold text-red-600">
                        {examResultsData.reduce((acc, curr) => curr.score < (viewingResultExam.questions.length / 2) ? acc + 1 : acc, 0)}
                      </div>
                      <div className="text-xs text-red-800 font-semibold uppercase">Số lượng trượt</div>
                    </div>
                  </div>

                  <div className="flex justify-end mb-4">
                     <button 
                        onClick={handleExportParticipantList}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-green-700 shadow-sm flex items-center gap-2 transition"
                     >
                        <span>📥</span> Tải danh sách (.xlsx)
                     </button>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-gray-100 text-gray-600 font-semibold border-b">
                        <tr>
                          <th className="px-4 py-3">#</th>
                          <th className="px-4 py-3">Họ và Tên</th>
                          <th className="px-4 py-3">Lớp</th>
                          <th className="px-4 py-3 text-center">Điểm số</th>
                          <th className="px-4 py-3 text-right">Ngày làm bài</th>
                          <th className="px-4 py-3 text-center">Thao tác</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {examResultsData.length > 0 ? (
                          examResultsData.map((res, idx) => {
                            const isPass = res.score >= (viewingResultExam.questions.length / 2);
                            return (
                              <tr key={idx} className="hover:bg-gray-50 transition">
                                <td className="px-4 py-3 text-gray-500">{idx + 1}</td>
                                <td className="px-4 py-3 font-medium text-gray-800">{res.name}</td>
                                <td className="px-4 py-3 text-gray-600">{res.className}</td>
                                <td className="px-4 py-3 text-center">
                                  <span className={`inline-block px-2 py-1 rounded font-bold text-xs ${isPass ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                    {res.score}/{viewingResultExam.questions.length}
                                  </span>
                                </td>
                                <td className="px-4 py-3 text-right text-gray-500 text-xs">
                                  {new Date(res.date).toLocaleString('vi-VN')}
                                </td>
                                <td className="px-4 py-3 text-center">
                                   <button 
                                      onClick={() => setSelectedStudentResult(res)}
                                      className="text-blue-600 hover:bg-blue-50 p-1.5 rounded-full transition"
                                      title="Xem chi tiết"
                                   >
                                      👁️
                                   </button>
                                </td>
                              </tr>
                            );
                          })
                        ) : (
                          <tr>
                            <td colSpan={6} className="px-4 py-8 text-center text-gray-400 italic">
                              Chưa có học sinh nào làm bài kiểm tra này.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </div>
            
            <div className="p-4 border-t bg-gray-50 rounded-b-xl flex justify-end">
              <button 
                onClick={() => setViewingResultExam(null)}
                className="px-5 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-semibold transition"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
           <h2 className="text-2xl font-bold text-gray-800">Quản Lý Đề Thi</h2>
           <p className="text-sm text-gray-500">
             {isAdmin ? 'Quản lý kho đề thi chính thức của hệ thống.' : 'Danh sách các bài kiểm tra có sẵn.'}
           </p>
        </div>
        
        {isAdmin && (
          <button 
            type="button"
            onClick={openNewEditor}
            className="bg-gradient-to-r from-bio-600 to-green-500 text-white px-8 py-3 rounded-full shadow-lg hover:shadow-xl font-bold flex items-center gap-2 transform transition-all hover:-translate-y-1 active:scale-95 text-base"
          >
            <span className="text-xl">+</span> Tạo Đề Mới
          </button>
        )}
      </div>

      {/* Admin Search & Filter Toolbar */}
      {isAdmin && !isCreating && (
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-4 animate-fade-in">
            <div className="flex-1">
                <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
                    <input 
                        type="text" 
                        placeholder="Tìm kiếm theo tên đề hoặc mã ID..."
                        className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-bio-500 outline-none"
                        value={adminSearchTerm}
                        onChange={(e) => setAdminSearchTerm(e.target.value)}
                    />
                </div>
            </div>
            <div className="w-full md:w-48">
                <select 
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-bio-500 outline-none bg-white"
                    value={adminCategoryFilter}
                    onChange={(e) => setAdminCategoryFilter(e.target.value)}
                >
                    <option value="ALL">Tất cả danh mục</option>
                    <option value="Sinh 10">Sinh 10</option>
                    <option value="Sinh 11">Sinh 11</option>
                    <option value="Sinh 12">Sinh 12</option>
                    <option value="Ôn TN THPT">Ôn TN THPT</option>
                </select>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm text-gray-600 font-semibold">
                <span>Tổng:</span>
                <span className="text-bio-600">{filteredExams.length}</span>
            </div>
        </div>
      )}

      {isCreating && (
        <div className="bg-white p-6 rounded-xl shadow-lg border-2 border-bio-100 mb-6 animate-fade-in">
          <h3 className="font-bold text-lg mb-4 text-bio-800 border-b pb-2">
            {editingExamId ? 'Chỉnh sửa đề thi' : 'Thiết lập đề thi mới'}
          </h3>
          
          <div className="space-y-4 mb-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Tên bài kiểm tra</label>
              <input 
                className="w-full border border-gray-300 p-2 rounded focus:ring-2 focus:ring-bio-500 outline-none" 
                placeholder="Ví dụ: Kiểm tra 1 tiết chương I - Chuyển hóa vật chất" 
                value={newExamTitle}
                onChange={e => setNewExamTitle(e.target.value)}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Khối Lớp / Danh Mục</label>
                  <select 
                    className="w-full border border-gray-300 p-2 rounded focus:ring-2 focus:ring-bio-500 outline-none bg-white"
                    value={newExamCategory}
                    onChange={e => setNewExamCategory(e.target.value as any)}
                  >
                    <option value="Sinh 10">Sinh Học 10</option>
                    <option value="Sinh 11">Sinh Học 11</option>
                    <option value="Sinh 12">Sinh Học 12</option>
                    <option value="Ôn TN THPT">Ôn thi TN THPT</option>
                  </select>
               </div>
               <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Thời gian làm bài (Phút)</label>
                  <input 
                    type="number" 
                    min="1"
                    className="w-full border border-gray-300 p-2 rounded focus:ring-2 focus:ring-bio-500 outline-none"
                    placeholder="45"
                    value={newExamDuration}
                    onChange={e => setNewExamDuration(parseInt(e.target.value) || 0)}
                  />
                  <p className="text-xs text-gray-500 mt-1">Hệ thống sẽ tự động nộp bài khi hết giờ.</p>
               </div>
            </div>
          </div>
          
          <div className="mb-6 bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="flex justify-between items-center mb-3">
                <p className="text-sm font-semibold text-gray-700">Danh sách câu hỏi ({parsedQuestions.length} câu)</p>
                <div className="flex gap-2">
                    <div className="relative">
                        <button 
                            type="button"
                            className="bg-white border border-gray-300 px-3 py-1.5 rounded text-sm hover:bg-gray-50 flex items-center gap-1"
                            onClick={() => document.getElementById('file-upload')?.click()}
                            disabled={isGenerating || isSavingExam}
                        >
                            📂 {isGenerating ? 'Đang xử lý...' : 'Upload PDF/Ảnh'}
                        </button>
                        <input 
                            id="file-upload" 
                            type="file" 
                            accept=".pdf,image/*"
                            className="hidden" 
                            onChange={handleFileUpload}
                        />
                    </div>
                    
                    <button 
                        type="button"
                        onClick={handleCreateWithAI}
                        disabled={isGenerating || isSavingExam}
                        className="bg-purple-600 text-white px-3 py-1.5 rounded text-sm hover:bg-purple-700 flex items-center gap-1 shadow-sm"
                    >
                        {isGenerating ? 'Đang tạo...' : '✨ Tạo bằng AI (Chủ đề)'}
                    </button>
                </div>
            </div>
            
            {uploadStatus && (
                <div className={`text-sm mb-3 px-3 py-2 rounded ${uploadStatus.includes('Lỗi') || uploadStatus.includes('Không') ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'}`}>
                    {uploadStatus}
                </div>
            )}
            
            {parsedQuestions.length > 0 ? (
               <div className="max-h-80 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                 {parsedQuestions.map((q, idx) => (
                   <div key={idx} className="text-sm p-3 bg-white border border-gray-200 rounded shadow-sm">
                     <div className="flex justify-between">
                        <span className="font-bold text-gray-800 mb-1">
                          Câu {idx + 1} ({q.type === 'TF' ? 'Đúng/Sai' : 'Trắc nghiệm'}):
                        </span>
                        <span className={`text-xs px-2 py-1 rounded font-bold ${
                           q.correctAnswer === 'Đúng' ? 'bg-green-100 text-green-700' : 
                           q.correctAnswer === 'Sai' ? 'bg-red-100 text-red-700' : 'bg-gray-100'
                        }`}>
                          Đ.Án: {q.correctAnswer}
                        </span>
                     </div>
                     <div className="text-gray-700 mb-2">{q.text}</div>

                     {/* Image Upload/View for Admin */}
                     <div className="mb-3">
                         {q.hasImage && !q.image && (
                           <div className="text-orange-600 text-xs font-bold mb-1 flex items-center gap-1 animate-pulse">
                              <span>⚠️</span> AI phát hiện câu này có hình ảnh. Vui lòng tải ảnh lên!
                           </div>
                         )}
                         {q.image && <img src={q.image} alt="Question Illustration" className="h-32 object-contain mb-2 border rounded" />}
                         <label className={`cursor-pointer text-xs px-2 py-1 rounded flex items-center gap-1 w-fit transition ${
                             q.hasImage && !q.image ? 'bg-orange-100 text-orange-700 border border-orange-200 ring-2 ring-orange-400' : 'bg-blue-50 text-blue-600 border border-blue-200 hover:bg-blue-100'
                         }`}>
                             <span>📷</span> {q.image ? 'Thay đổi ảnh' : 'Thêm ảnh minh họa'}
                             <input 
                                type="file" 
                                className="hidden" 
                                accept="image/*" 
                                onChange={(e) => handleQuestionImageUpload(idx, e.target.files?.[0])} 
                             />
                         </label>
                     </div>

                     <div className={`grid gap-2 text-xs text-gray-500 ${q.type === 'TF' ? 'grid-cols-2' : 'grid-cols-2'}`}>
                        {q.options.map((opt, i) => {
                            let isCorrect = false;
                            if (q.type === 'MCQ') {
                                const letters = ['A','B','C','D'];
                                isCorrect = letters[i] === q.correctAnswer;
                            } else {
                                isCorrect = opt === q.correctAnswer;
                            }

                            return (
                                <div key={i} className={isCorrect ? 'text-green-600 font-bold bg-green-50 p-1 rounded border border-green-200' : 'p-1'}>
                                    {q.type === 'MCQ' ? ['A.','B.','C.','D.'][i] : ''} {opt.replace(/^[A-D]\.\s*/, '')}
                                </div>
                            )
                        })}
                     </div>
                   </div>
                 ))}
               </div>
            ) : (
                <div className="text-center py-8 text-gray-400 border-2 border-dashed border-gray-300 rounded">
                    Chưa có câu hỏi nào.
                    <br/><span className="text-xs">Upload file đề thi (PDF/Ảnh) có gạch chân đáp án đúng để trích xuất tự động.</span>
                </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <button type="button" onClick={closeEditor} className="px-5 py-2 text-gray-600 font-medium hover:bg-gray-100 rounded">Huỷ bỏ</button>
            <button 
                type="button" 
                onClick={saveNewExam} 
                disabled={isSavingExam}
                className="bg-bio-600 text-white px-6 py-2 rounded font-bold shadow hover:bg-bio-700 transition disabled:bg-gray-400 flex items-center gap-2"
            >
              {isSavingExam && <span className="animate-spin text-white">⏳</span>}
              {editingExamId ? 'Lưu Thay Đổi' : 'Lưu & Phát Hành'}
            </button>
          </div>
        </div>
      )}

      <div className="grid gap-4">
        {isLoading ? (
            <div className="text-center py-20 bg-white rounded-xl shadow-sm border border-gray-100">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-bio-200 border-t-bio-600 mb-2"></div>
                <p className="text-gray-500 font-medium animate-pulse">Đang tải danh sách đề...</p>
            </div>
        ) : filteredExams.map(exam => (
          <div key={exam.id} className="bg-white p-5 rounded-lg shadow-sm border border-gray-100 flex flex-col sm:flex-row justify-between items-start sm:items-center hover:shadow-md transition gap-4">
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="text-xs font-bold bg-white text-red-700 border border-red-200 px-3 py-1 rounded-full shadow-sm">{exam.category}</span>
                <h3 className="font-bold text-gray-800 text-lg flex-1">{exam.title}</h3>
                <span className="text-[10px] text-gray-400 bg-gray-50 px-1 rounded border">ID: {exam.id}</span>
              </div>
              <div className="flex flex-wrap gap-2 text-xs mb-1">
                  <span className="bg-white text-red-700 border border-red-200 px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-sm font-bold">
                      📝 {exam.questions.length} câu
                  </span>
                  <span className="bg-white text-red-700 border border-red-200 px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-sm font-bold">
                      ⏱️ {exam.duration} phút
                  </span>
                  {/* Creator Info Tag */}
                  <span className="bg-white text-blue-700 border border-blue-200 px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-sm font-bold" title="Người tạo đề">
                      👤 {exam.createdBy || 'Hệ thống'}
                  </span>
                  {/* Creation Date Tag */}
                  {exam.createdAt && (
                    <span className="bg-white text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-sm font-bold" title="Ngày tạo đề">
                      📅 {new Date(exam.createdAt).toLocaleDateString('vi-VN')}
                    </span>
                  )}
              </div>
            </div>
            
            <div className="flex gap-2 w-full sm:w-auto">
              {isAdmin && (
                <>
                  <button 
                    type="button"
                    onClick={() => handleViewResults(exam)}
                    className="flex-1 sm:flex-none bg-blue-50 text-blue-700 border border-blue-200 px-3 py-2 rounded text-sm font-medium hover:bg-blue-100 transition flex items-center justify-center gap-1"
                  >
                    📊 Kết quả
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleEditExam(exam)}
                    className="flex-1 sm:flex-none bg-yellow-50 text-yellow-700 border border-yellow-200 px-3 py-2 rounded text-sm font-medium hover:bg-yellow-100 transition"
                  >
                    ✏️ Sửa
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleDeleteExam(exam.id)}
                    className="flex-1 sm:flex-none bg-red-50 text-red-700 border border-red-200 px-3 py-2 rounded text-sm font-medium hover:bg-red-600 hover:text-white transition"
                  >
                    🗑️ Xóa
                  </button>
                </>
              )}
              <button 
                type="button"
                onClick={() => handleStartExam(exam)}
                className="flex-1 sm:flex-none bg-bio-600 text-white px-5 py-2 rounded text-sm font-bold hover:bg-bio-700 shadow-sm transition"
              >
                {isAdmin ? 'Xem thử' : 'Làm bài'}
              </button>
            </div>
          </div>
        ))}
        
        {!isLoading && filteredExams.length === 0 && (
          <div className="text-center py-16 bg-white rounded-xl border border-dashed border-gray-300">
            <div className="text-4xl mb-4">📭</div>
            <p className="text-gray-500 mb-2">{adminSearchTerm ? 'Không tìm thấy kết quả phù hợp.' : 'Chưa có đề thi nào trong hệ thống.'}</p>
            {isAdmin && !adminSearchTerm && <p className="text-bio-600 font-medium cursor-pointer" onClick={openNewEditor}>Hãy nhấn "Tạo Đề Mới" để bắt đầu.</p>}
          </div>
        )}
      </div>
    </div>
  );
};
