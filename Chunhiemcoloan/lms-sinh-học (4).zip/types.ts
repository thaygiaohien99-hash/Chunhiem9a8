
export enum UserRole {
  STUDENT = 'STUDENT',
  ADMIN = 'ADMIN'
}

export enum UserLevel {
  LEVEL_1 = 'Nhập Môn',
  LEVEL_2 = 'Thông Hiểu',
  LEVEL_3 = 'Kì Tài',
  LEVEL_4 = 'Bá Chủ'
}

export interface User {
  phone: string;
  name: string;
  className?: string; // Optional for Admin
  password?: string; // In real app, never store plain text
  role: UserRole;
  totalScore: number;
  examHistory: ExamResult[];
}

export interface Question {
  id: string;
  text: string;
  image?: string; // Base64 string or URL for question image
  hasImage?: boolean; // Flag detected by AI if question mentions an image
  type: 'MCQ' | 'TF'; // Multiple Choice or True/False
  options: string[]; // A, B, C, D or a, b, c, d (True/False)
  correctAnswer: string; // Index or Value
}

export interface Exam {
  id: string;
  title: string;
  category: string; // Changed from enum to string to support Battle types
  duration: number; // minutes
  questions: Question[];
  createdBy: string;
  isLocked?: boolean; // New field for Battle locking
  createdAt?: string; // Timestamp for creation limit check
}

export interface ExamResultDetail {
  questionId: string;
  questionText: string;
  userAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
}

export interface ExamResult {
  examId: string;
  examTitle: string;
  score: number; // Max 15
  date: string;
  // Extended fields for Google Sheet reporting
  startTime?: string;
  endTime?: string;
  detailedAnswers?: ExamResultDetail[];
  // Added totalQuestions to resolve property access error in ProfileView and track exam size
  totalQuestions?: number;
}

export interface BattleRoom {
  id: string;
  code: string;
  host: string;
  players: string[];
  status: 'WAITING' | 'PLAYING' | 'FINISHED';
}

export const BIO_TOPICS = {
  'Sinh 10': [
    'Thành phần hóa học của tế bào',
    'Cấu trúc tế bào',
    'Trao đổi chất và chuyển hóa năng lượng ở tế bào',
    'Chu kì tế bào, phân bào và công nghệ tế bào',
    'Vi sinh vật và ứng dụng',
    'Virus và ứng dụng'
  ],
  'Sinh 11': [
    'Trao đổi chất và chuyển hóa năng lượng ở sinh vật',
    'Cảm ứng ở sinh vật',
    'Sinh trưởng và phát triển ở sinh vật',
    'Sinh sản ở sinh vật'
  ],
  'Sinh 12': [
    'Di truyền phân tử và di truyền nhiễm sắc thể',
    'Tương tác giữa kiểu gene với môi trường và thành tựu chọn giống',
    'Di truyền quần thể và di truyền học người',
    'Bằng chứng và cơ chế tiến hoá',
    'Sự phát sinh và phát triển của sự sống trên Trái Đất',
    'Môi trường và quần thể sinh vật',
    'Quần xã sinh vật và hệ sinh thái',
    'Sinh thái học phục hồi, bảo tồn và phát triển bền vững'
  ]
};
