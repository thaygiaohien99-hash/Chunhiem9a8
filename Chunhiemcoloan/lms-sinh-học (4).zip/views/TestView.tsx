
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { createPortal } from 'react-dom';
import * as XLSX from 'xlsx'; // Import SheetJS
import { User, UserRole, Exam, Question, ExamResult, ExamResultDetail } from '../types';
import { getExams, publishExamToCloud, submitExamResultToCloud, deleteExamFromCloud, getExamParticipants } from '../services/dataService';
import { generateBiologyQuestions, generateQuestionsFromDocument } from '../services/geminiService';

interface TestViewProps {
  user: User;
  onUpdateUser: (updatedUser: User) => void;
  setNavigationBlocker?: React.Dispatch<React.SetStateAction<(() => boolean) | null>>;
}

export const TestView: React.FC<TestViewProps> = ({ user, onUpdateUser, setNavigationBlocker }) => {
  const isAdmin = user.role === UserRole.ADMIN;
  const [exams, setExams] = useState<Exam[]>([]);
  const [activeExam, setActiveExam] = useState<Exam | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Student State
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [score, setScore] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [startTime, setStartTime] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [reviewFilter, setReviewFilter] = useState<'ALL' | 'INCORRECT'>('ALL');
  const [submissionReason, setSubmissionReason] = useState<string | null>(null);

  // Admin State
  const [isCreating, setIsCreating] = useState(false);
  const [editingExamId, setEditingExamId] = useState<string | null>(null);
  const [newExamTitle, setNewExamTitle] = useState('');
  const [newExamCategory, setNewExamCategory] = useState<Exam['category']>('Sinh 12');
  const [newExamDuration, setNewExamDuration] = useState<number>(45);
  const [parsedQuestions, setParsedQuestions] = useState<Question[]>([]);
  const [editingQuestionIndex, setEditingQuestionIndex] = useState<number | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string>('');
  const [isSavingExam, setIsSavingExam] = useState(false);

  // Admin Search & Filter State
  const [adminSearchTerm, setAdminSearchTerm] = useState('');
  const [adminCategoryFilter, setAdminCategoryFilter] = useState<string>('ALL');

  const loadExams = async () => {
    setIsLoading(true);
    try {
        const data = await getExams();
        setExams(data.filter(e => e.category !== 'BATTLE'));
    } catch (error) {
        console.error("Failed to load exams", error);
    } finally {
        setIsLoading(false);
    }
  };

  useEffect(() => {
    loadExams();
  }, []);

  const filteredExams = useMemo(() => {
    const sorted = [...exams].sort((a, b) => {
        const timeA = a.createdAt ? new Date(a.createdAt).getTime() : (parseInt(a.id) || 0);
        const timeB = b.createdAt ? new Date(b.createdAt).getTime() : (parseInt(b.id) || 0);
        return timeB - timeA;
    });

    if (!isAdmin) return sorted;
    
    return sorted.filter(exam => {
        const matchesSearch = exam.title.toLowerCase().includes(adminSearchTerm.toLowerCase()) || 
                              exam.id.includes(adminSearchTerm);
        const matchesCategory = adminCategoryFilter === 'ALL' || exam.category === adminCategoryFilter;
        return matchesSearch && matchesCategory;
    });
  }, [exams, isAdmin, adminSearchTerm, adminCategoryFilter]);

  const isNewExam = (dateString?: string) => {
    if (!dateString) return false;
    const createdDate = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - createdDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 3; // Coi là mới nếu trong vòng 3 ngày
  };

  // Logic làm bài, nộp bài, admin handlers (giữ nguyên logic cũ nhưng cập nhật UI card bên dưới)
  // ... [Logic nộp bài, timer, admin editor giữ nguyên như file gốc] ...
  const handleStartExam = (exam: Exam) => {
    setActiveExam(exam);
    setAnswers({});
    setScore(null);
    setTimeLeft(exam.duration * 60);
    setStartTime(new Date().toISOString()); 
    setReviewFilter('ALL');
    setSubmissionReason(null); 
  };

  const handleExitExam = () => {
     setActiveExam(null);
     setScore(null);
  };

  const handleAnswer = (qId: string, val: string) => {
    setAnswers(prev => ({ ...prev, [qId]: val }));
  };

  const handleSubmitExam = async (isAuto: boolean = false) => {
    if (!activeExam) return;
    setIsSubmitting(true);
    const endTime = new Date().toISOString();
    let correctCount = 0;
    activeExam.questions.forEach(q => {
      if (answers[q.id] === q.correctAnswer) correctCount++;
    });
    const result: ExamResult = {
      examId: activeExam.id,
      examTitle: activeExam.title,
      score: correctCount,
      date: endTime,
      totalQuestions: activeExam.questions.length
    };
    await submitExamResultToCloud(user.phone, result);
    setScore(correctCount);
    setIsSubmitting(false);
  };

  const openNewEditor = () => {
    setIsCreating(true);
    setEditingExamId(null);
    setNewExamTitle('');
    setParsedQuestions([]);
  };

  const closeEditor = () => setIsCreating(false);

  const saveNewExam = async () => {
    if (!newExamTitle || parsedQuestions.length === 0) return alert('Thiếu thông tin');
    setIsSavingExam(true);
    const examData: Exam = {
      id: editingExamId || Date.now().toString(),
      title: newExamTitle,
      category: newExamCategory,
      duration: newExamDuration,
      questions: parsedQuestions,
      createdBy: user.name,
      createdAt: new Date().toISOString()
    };
    await publishExamToCloud(examData);
    loadExams();
    closeEditor();
    setIsSavingExam(false);
  };

  const handleEditExam = (exam: Exam) => {
    setEditingExamId(exam.id);
    setNewExamTitle(exam.title);
    setNewExamCategory(exam.category);
    setNewExamDuration(exam.duration);
    setParsedQuestions(exam.questions);
    setIsCreating(true);
  };

  const handleDeleteExam = async (examId: string) => {
    if (confirm('Xóa đề thi này?')) {
        await deleteExamFromCloud(examId);
        loadExams();
    }
  };

  const handleUpdateQuestion = (index: number, field: keyof Question, value: any) => {
    const updated = [...parsedQuestions];
    updated[index] = { ...updated[index], [field]: value };
    setParsedQuestions(updated);
  };

  const handleUpdateOption = (qIndex: number, optIndex: number, value: string) => {
    const updated = [...parsedQuestions];
    const newOptions = [...updated[qIndex].options];
    newOptions[optIndex] = value;
    updated[qIndex] = { ...updated[qIndex], options: newOptions };
    setParsedQuestions(updated);
  };

  const handleAddManualQuestion = () => {
    setParsedQuestions(prev => [...prev, { id: `m-${Date.now()}`, text: '', type: 'MCQ', options: ['', '', '', ''], correctAnswer: 'A' }]);
    setEditingQuestionIndex(parsedQuestions.length);
  };

  if (activeExam) {
    return (
      <div className="max-w-4xl mx-auto p-4 md:p-8">
        {score !== null ? (
            <div className="bg-white p-8 rounded-2xl shadow-xl text-center">
                <div className="text-6xl mb-4">🎉</div>
                <h2 className="text-2xl font-bold mb-2">Hoàn Thành!</h2>
                <div className="text-5xl font-bold text-bio-600 mb-6">{score}/{activeExam.questions.length}</div>
                <button onClick={handleExitExam} className="bg-bio-600 text-white px-8 py-3 rounded-xl font-bold">Quay lại</button>
            </div>
        ) : (
            <div className="space-y-6">
                <div className="bg-white p-4 rounded-xl shadow sticky top-20 z-10 flex justify-between items-center">
                    <h2 className="font-bold text-lg truncate pr-4">{activeExam.title}</h2>
                    <div className="bg-red-50 text-red-600 px-4 py-2 rounded-lg font-mono font-bold">
                        {Math.floor(timeLeft / 60)}:{String(timeLeft % 60).padStart(2, '0')}
                    </div>
                </div>
                {activeExam.questions.map((q, idx) => (
                    <div key={idx} className="bg-white p-6 rounded-xl shadow border border-gray-100">
                        <p className="font-bold mb-4">Câu {idx + 1}: {q.text}</p>
                        <div className="grid gap-3">
                            {q.options.map((opt, i) => {
                                const label = ['A', 'B', 'C', 'D'][i];
                                return (
                                    <button key={i} onClick={() => handleAnswer(q.id, label)} className={`text-left p-4 rounded-xl border transition-all ${answers[q.id] === label ? 'bg-bio-600 text-white border-bio-600' : 'bg-white hover:bg-bio-50 border-gray-200'}`}>
                                        <span className="font-bold mr-2">{label}.</span> {opt}
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                ))}
                <button onClick={() => handleSubmitExam(false)} className="w-full bg-bio-700 text-white py-4 rounded-2xl font-bold shadow-lg">NỘP BÀI</button>
            </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
            <h2 className="text-2xl font-bold text-gray-800">Thư Viện Đề Thi</h2>
            <p className="text-sm text-gray-500">Hệ thống bài tập tự luyện và kiểm tra định kỳ.</p>
        </div>
        {isAdmin && (
            <button onClick={openNewEditor} className="bg-gradient-to-r from-bio-600 to-green-500 text-white px-8 py-3 rounded-full shadow-lg font-bold hover:-translate-y-1 transition">+ Tạo Đề Mới</button>
        )}
      </div>

      {isAdmin && !isCreating && (
        <div className="bg-white p-4 rounded-xl shadow-sm border flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
                <input type="text" placeholder="Tìm kiếm đề thi..." className="w-full pl-10 pr-4 py-2 border rounded-lg outline-none" value={adminSearchTerm} onChange={(e) => setAdminSearchTerm(e.target.value)} />
            </div>
            <select className="px-4 py-2 border rounded-lg bg-white outline-none" value={adminCategoryFilter} onChange={(e) => setAdminCategoryFilter(e.target.value)}>
                <option value="ALL">Tất cả danh mục</option>
                <option value="Sinh 10">Sinh 10</option>
                <option value="Sinh 11">Sinh 11</option>
                <option value="Sinh 12">Sinh 12</option>
            </select>
        </div>
      )}

      {isCreating && (
        <div className="bg-white p-6 rounded-xl shadow-lg border-2 border-bio-100 animate-fade-in">
          <h3 className="font-bold text-lg mb-4 text-bio-800 border-b pb-2">{editingExamId ? 'Chỉnh sửa đề thi' : 'Thiết lập đề thi mới'}</h3>
          <div className="space-y-4 mb-6">
            <input className="w-full border p-2 rounded outline-none" placeholder="Tên đề thi" value={newExamTitle} onChange={e => setNewExamTitle(e.target.value)} />
            <div className="grid grid-cols-2 gap-4">
               <select className="border p-2 rounded bg-white" value={newExamCategory} onChange={e => setNewExamCategory(e.target.value as any)}>
                 <option value="Sinh 10">Sinh 10</option>
                 <option value="Sinh 11">Sinh 11</option>
                 <option value="Sinh 12">Sinh 12</option>
               </select>
               <input type="number" className="border p-2 rounded" placeholder="Phút" value={newExamDuration} onChange={e => setNewExamDuration(parseInt(e.target.value) || 0)} />
            </div>
          </div>
          <div className="mb-6 bg-gray-50 p-4 rounded-lg border">
            <div className="flex justify-between items-center mb-3">
                <p className="text-sm font-semibold">Câu hỏi ({parsedQuestions.length})</p>
                <button onClick={handleAddManualQuestion} className="bg-bio-100 text-bio-700 px-3 py-1 rounded text-xs font-bold border border-bio-200">+ Thêm</button>
            </div>
            <div className="max-h-64 overflow-y-auto space-y-3">
                {parsedQuestions.map((q, idx) => (
                    <div key={idx} className="p-3 bg-white border rounded text-xs">
                        <input className="w-full font-bold mb-2 outline-none" value={q.text} onChange={e => handleUpdateQuestion(idx, 'text', e.target.value)} placeholder={`Câu hỏi ${idx+1}`} />
                        <div className="grid grid-cols-2 gap-2">
                            {q.options.map((o, oi) => (
                                <input key={oi} className="p-1 border rounded" value={o} onChange={e => handleUpdateOption(idx, oi, e.target.value)} placeholder={`Đáp án ${['A','B','C','D'][oi]}`} />
                            ))}
                        </div>
                    </div>
                ))}
            </div>
          </div>
          <div className="flex justify-end gap-3"><button onClick={closeEditor} className="px-4 py-2">Hủy</button><button onClick={saveNewExam} className="bg-bio-600 text-white px-6 py-2 rounded font-bold">{isSavingExam ? 'Đang lưu...' : 'Lưu'}</button></div>
        </div>
      )}

      <div className="grid gap-4">
        {isLoading ? (
            <div className="text-center py-20 bg-white rounded-xl shadow-sm border"><div className="animate-spin rounded-full h-8 w-8 border-4 border-t-bio-600 mx-auto mb-2"></div><p className="text-gray-500">Đang tải...</p></div>
        ) : filteredExams.map(exam => {
          const isNew = isNewExam(exam.createdAt);
          return (
            <div key={exam.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col sm:flex-row justify-between items-start sm:items-center hover:shadow-md transition gap-4 relative overflow-hidden">
              {isNew && (
                <div className="absolute top-0 right-0">
                  <div className="bg-red-500 text-white text-[10px] font-bold px-4 py-1 transform rotate-45 translate-x-3 translate-y-1 shadow-sm">MỚI</div>
                </div>
              )}
              
              <div className="flex-1 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-red-600 bg-red-50 border border-red-100 px-2 py-0.5 rounded-full">{exam.category}</span>
                  <h3 className="font-bold text-gray-800 text-lg leading-tight">{exam.title}</h3>
                </div>
                
                <div className="flex flex-wrap gap-3">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-gray-500 bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-100">
                    <span>📝</span> {exam.questions.length} câu
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-gray-500 bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-100">
                    <span>⏱️</span> {exam.duration} phút
                  </div>
                  {exam.createdAt && (
                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-100">
                      <span>📅</span> {new Date(exam.createdAt).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 text-[10px] text-gray-400">
                  <span className="bg-blue-50 text-blue-600 px-2 py-0.5 rounded border border-blue-100 font-bold">👤 {exam.createdBy || 'Hệ thống'}</span>
                  <span className="opacity-60 italic">ID: {exam.id}</span>
                </div>
              </div>

              <div className="flex gap-2 w-full sm:w-auto">
                {isAdmin && (
                  <>
                    <button onClick={() => handleEditExam(exam)} className="flex-1 sm:flex-none bg-yellow-50 text-yellow-700 border border-yellow-200 p-2.5 rounded-lg hover:bg-yellow-100 transition"><span className="text-sm">✏️ Sửa</span></button>
                    <button onClick={() => handleDeleteExam(exam.id)} className="flex-1 sm:flex-none bg-red-50 text-red-700 border border-red-200 p-2.5 rounded-lg hover:bg-red-100 transition"><span className="text-sm">🗑️ Xóa</span></button>
                  </>
                )}
                <button 
                  onClick={() => handleStartExam(exam)} 
                  className="flex-1 sm:flex-none bg-bio-600 text-white px-8 py-2.5 rounded-lg font-bold hover:bg-bio-700 shadow-md transform active:scale-95 transition"
                >
                  {isAdmin ? 'Xem thử' : 'Làm bài'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
